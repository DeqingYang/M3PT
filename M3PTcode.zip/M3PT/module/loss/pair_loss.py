import torch
from torch import nn, Tensor
import torch.nn.functional as F

def convert_label_to_similarity(normed_feature, label):
    similarity_matrix = normed_feature @ normed_feature.transpose(1, 0)

    label_matrix = label.unsqueeze(1) == label.unsqueeze(0)

    positive_matrix = label_matrix.triu(diagonal=1)
    negative_matrix = label_matrix.logical_not().triu(diagonal=1)

    similarity_matrix = similarity_matrix.view(-1)
    positive_matrix = positive_matrix.view(-1)
    negative_matrix = negative_matrix.view(-1)
    return similarity_matrix[positive_matrix], similarity_matrix[negative_matrix]

def pos_neg_rate(normed_feature, label):
    similarity_matrix = normed_feature @ normed_feature.transpose(1, 0)

    # label_matrix = torch.eye(normed_feature.shape[0]) > 0
    label_matrix = label.unsqueeze(1) == label.unsqueeze(0)

    positive_matrix = label_matrix.triu(diagonal=1)
    negative_matrix = label_matrix.logical_not().triu(diagonal=1)

    pos_num = (similarity_matrix * positive_matrix > 0).sum() + (similarity_matrix * negative_matrix < 0).sum()
    neg_num = (similarity_matrix * positive_matrix < 0).sum() + (similarity_matrix * negative_matrix > 0).sum()

    if neg_num <= 0:
        return 0
    return pos_num/neg_num

class CircleLoss(nn.Module):
    def __init__(self, m, gamma):
        super(CircleLoss, self).__init__()
        self.m = m
        self.gamma = gamma
        self.soft_plus = nn.Softplus()

    def forward(self, sp, sn):
        # ap = torch.clamp_min(- sp.detach() + 1 + self.m, min=0.)
        # an = torch.clamp_min(sn.detach() + self.m, min=0.)

        ap = torch.clamp_min(- sp + 1 + self.m, min=0.)
        an = torch.clamp_min(sn + self.m, min=0.)

        delta_p = 1 - self.m
        delta_n = self.m

        logit_p = - ap * (sp - delta_p) * self.gamma
        logit_n = an * (sn - delta_n) * self.gamma

        loss = self.soft_plus(torch.logsumexp(logit_n, dim=0) + torch.logsumexp(logit_p, dim=0))

        return loss

class TripleLoss(nn.Module):
    def __init__(self, margin=0, max_violation=False):
        super(TripleLoss, self).__init__()
        self.margin = margin
        self.max_violation = max_violation

    def forward(self, im, label):
        # compute image-sentence score matrix
        similarity_matrix = im @ im.transpose(1, 0)
        label_matrix = label.unsqueeze(1) == label.unsqueeze(0)

        positive_matrix = label_matrix.triu(diagonal=1)
        negative_matrix = label_matrix.logical_not().triu(diagonal=1)

        error_pos = ((similarity_matrix - self.margin) * positive_matrix) < 0
        error_neg = ((similarity_matrix + self.margin) * negative_matrix) > 0

        cost_p = -1 * (similarity_matrix - self.margin) * error_pos
        cost_n = (similarity_matrix + self.margin) * error_neg

        return cost_p.sum() + cost_n.sum()

def single_emd_loss(p, q, r=2):
    """
    Earth Mover's Distance of one sample

    Args:
        p: true distribution of shape num_classes × 1
        q: estimated distribution of shape num_classes × 1
        r: norm parameter
    """
    assert p.shape == q.shape, "Length of the two distribution must be the same"
    length = p.shape[0]
    emd_loss = 0.0
    for i in range(1, length + 1):
        emd_loss += torch.abs(sum(p[:i] - q[:i])) ** r
    return (emd_loss / length) ** (1. / r)

def emd_loss(p, q, r=2):
    """
    Earth Mover's Distance on a batch

    Args:
        p: true distribution of shape mini_batch_size × num_classes × 1
        q: estimated distribution of shape mini_batch_size × num_classes × 1
        r: norm parameters
    """
    assert p.shape == q.shape, "Shape of the two distribution batches must be the same."
    mini_batch_size = p.shape[0]
    loss_vector = []
    for i in range(mini_batch_size):
        loss_vector.append(single_emd_loss(p[i], q[i], r=r))
    return sum(loss_vector) / mini_batch_size


def focal_loss(input, target, alpha=1.0, gamma=1.0, 
               reduction='mean', eps=1e-8):
    # compute softmax over the classes axis
    input_soft = F.softmax(input, dim=1) + eps
    target_one_hot = F.one_hot(target, num_classes=input.shape[1])
    # compute the actual focal loss
    weight = torch.pow(-input_soft + 1.0, gamma)
    focal = -alpha * weight * torch.log(input_soft)
    loss_tmp = torch.sum(target_one_hot * focal, dim=1)
    if reduction == 'mean':
        loss = torch.mean(loss_tmp)
    elif reduction == 'sum':
        loss = torch.sum(loss_tmp)
    else:
        raise NotImplementedError("Invalid reduction mode: {}".format(reduction))
    return loss


def easy_triplet_loss(pos_distance, neg_distance, margin):
    return torch.clamp(pos_distance.sum(axis=1) - neg_distance.sum(axis=1)/(neg_distance.shape[0]-1) + margin, min=0).mean()

def hard_triplet_loss(pos_distance, neg_distance, margin):
    return torch.clamp(pos_distance.sum(axis=1) - neg_distance.min(axis=1)[0] + margin, min=0).mean()

def get_triplet_loss(distance, loss_weights=[1, 0], margin=0.3, bidirection=True):
    '''
    计算 semi-hard triplet loss
    Args:
        distance: N*N, image_embedding 与 text_embedding 的距离
        loss_weights: easy loss 与 hard loss 的权重，长度为2
        margin: triplet loss margin
        bidirection：是否使用“图-文”、“文-图”双向 loss
    '''
    batch_size = distance.shape[0]
    pos_mask = torch.eye(batch_size, device=distance.device, dtype=distance.dtype)
    neg_mask = (torch.ones_like(distance) - pos_mask) > 0
    pos_mask = pos_mask > 0
    pos_distance = torch.masked_select(distance, pos_mask).reshape((batch_size, 1))
    neg_distance = torch.masked_select(distance, neg_mask).reshape((batch_size, batch_size-1))
    neg_distance_t2i = torch.masked_select(distance.T, neg_mask).reshape((batch_size, batch_size-1))
    easy_loss_i2t, easy_loss_t2i, hard_loss_i2t, hard_loss_t2i = 0, 0, 0, 0
    if loss_weights[0] != 0:
        easy_loss_i2t = easy_triplet_loss(pos_distance, neg_distance, margin) * loss_weights[0]
        if bidirection:
            easy_loss_t2i = easy_triplet_loss(pos_distance, neg_distance_t2i, margin) * loss_weights[0]

    if loss_weights[1] != 0:
        hard_loss_i2t = hard_triplet_loss(pos_distance, neg_distance, margin) * loss_weights[1]
        if bidirection:
            hard_loss_t2i = hard_triplet_loss(pos_distance, neg_distance_t2i, margin) * loss_weights[1]

    loss = easy_loss_i2t + easy_loss_t2i + hard_loss_i2t + hard_loss_t2i

    return loss

def contrastive_loss(sims):
    # sims = (image_embed @ text_embed.t()) / temp

    # labels = torch.arange(image_embed.shape[0], dtype=torch.long, device=image_embed.device)
    # loss = (F.cross_entropy(sims, labels) + F.cross_entropy(sims.t(), labels)) / 2
    batch_size = sims.shape[1]
    positives = torch.diag(sims)
    nominator = torch.exp(positives)
    denominator = torch.exp(sims)
    loss_partial = -torch.log(nominator / torch.sum(denominator, dim=0))
    loss = torch.sum(loss_partial)/batch_size

    return loss

def simcse_loss(y_pred, tao=0.05):
    idxs = torch.arange(0, y_pred.shape[0], device=y_pred.device)
    y_true = idxs + 1 - idxs % 2 * 2
    similarities = F.cosine_similarity(y_pred.unsqueeze(1), y_pred.unsqueeze(0), dim=2)
    similarities = similarities - torch.eye(y_pred.shape[0], device=y_pred.device) * 1e12
    similarities = similarities / tao
    loss = F.cross_entropy(similarities, y_true)
    return torch.mean(loss)


if __name__ == "__main__":
    feat = nn.functional.normalize(torch.rand(6, 64, requires_grad=True))

    label = torch.Tensor([1,1,2,2,3,3])
    # inp_sp, inp_sn = pos_neg_rate(feat, label)

    # print(inp_sp, inp_sn)

    # criterion = CircleLoss(m=0.25, gamma=256)
    # circle_loss = criterion(inp_sp, inp_sn)

    criterion = TripleLoss()
    loss = criterion(feat, label)

    print(loss)
