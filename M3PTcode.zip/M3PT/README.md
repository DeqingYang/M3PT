

## 架构
```
M3PT
    data # 数据预处理和加载相关
    demo # 测试代码目录
    model # 模型代码
    module # backbone, loss, optim, schelduler等基础代码
    runs # 运行summary和模型保存目录
    server # onnx 调用服务，去除原始代码
    task # 任务代码目录，每个任务包括训练、测试及相关配置
    tools # 其他工具
    util # 基础函数目录
    weights # 模型文件目录
```

