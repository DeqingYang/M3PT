'''
层次分类头
'''

import torch 
import numpy as np
from torch import nn
import torch.nn.functional as F
import random 

def logits_clamp(logits):
    logits = torch.clamp(logits,  -50.0, 50.0)
    return logits

def one_hot(labels, num_classes, device, dtype):
    batch_size = labels.shape[0]
    one_hot = torch.zeros(batch_size, num_classes, device=device, dtype=dtype)
    return one_hot.scatter_(1, labels.unsqueeze(1), 1.0)

class FocalLoss(nn.Module):
    def __init__(self, alpha, gamma=2.0):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.eps = 1e-6

    def forward(self, input, target, reduction='none', norm=False):
        if norm:
            input_soft = nn.softmax(input, dim=1) + self.eps
        else:
            input_soft = input + self.eps
        # create the labels one hot tensor
        target_one_hot = one_hot(target, num_classes=input.shape[1],
                                 device=input.device, dtype=input.dtype)

        # compute the actual focal loss
        weight = torch.pow(1. - input_soft, self.gamma)
        focal = - weight * torch.log(input_soft)
        loss_tmp = torch.sum(target_one_hot * focal, dim=1)

        loss = -1
        if reduction == 'none':
            loss = loss_tmp
        elif reduction == 'mean':
            loss = torch.mean(loss_tmp)
        elif reduction == 'sum':
            loss = torch.sum(loss_tmp)
        else:
            raise NotImplementedError("Invalid reduction mode: {}"
                                      .format(reduction))
        return loss

def semi_supversion_labels(probabilities, semi_index, threshold=0.99, device="cuda"):
    #通过torch.index_select挑出需要进行半监督的样本
    semi_probabilities = torch.index_select(probabilities, 0, semi_index)
    batch_size = semi_probabilities.shape[0]
    p, q = torch.split(semi_probabilities, batch_size//2, dim = 0)

    mean_probabilties = torch.mean(torch.stack([p, q]), 0)


    #获取probabilities的batch_size，labels的维度为[batch_size, 1]
    mean_batch_size = mean_probabilties.shape[0]
    shape_tensor = torch.tensor([mean_batch_size])
    #构造全-1和1的向量
    neg_ones = torch.ones_like(shape_tensor)*torch.tensor(-1)
    neg_ones = neg_ones.to(device)
    ones = torch.ones_like(shape_tensor).to(device)

    prob_max, prob_max_index = torch.max(mean_probabilties, axis=1)

    threshold = torch.tensor(threshold).to(device)
    over_threshold_index = torch.where(prob_max > threshold, ones, neg_ones)
    semi_labels = prob_max_index * over_threshold_index
    semi_labels = torch.cat((semi_labels, semi_labels), 0)
    
    #当label为0时 50%丢失
    semi_labels_np = semi_labels.cpu().numpy()
    semi_labels_filter = []
    for label in semi_labels_np:
        if int(label) != 0:
            semi_labels_filter.append(int(label))
        else:
            if random.random() < 0.5:
                semi_labels_filter.append(int(label))
            else:
                semi_labels_filter.append(-1)
    semi_labels = torch.tensor(semi_labels_filter).to(device)
    return semi_probabilities, semi_labels

def semi_supversion_labels_merge(probabilities, semi_index,  T=0.5):
    #通过torch.index_select挑出需要进行半监督的样本
    semi_probabilities = torch.index_select(probabilities, 0, semi_index)

    #获取probabilities的batch_size，labels的维度为[batch_size, 1]
    batch_size = semi_probabilities.shape[0]
    p, q = torch.split(semi_probabilities, batch_size//2, dim = 0)

    mean_probabilties = torch.mean(torch.stack([p, q]), 0)
    #T进行平滑下，防止除0
    T = T+0.001
    mean_probabilties = F.softmax(mean_probabilties/T, dim=1)

    mean_probabilties = torch.cat((mean_probabilties, mean_probabilties), 0)
    return semi_probabilities, mean_probabilties

def classification_loss(labels, logits, loss_func=nn.functional.cross_entropy):

    #常规需要计算的loss
    clone_labels = labels.clone()
    #label为-1的mask
    mask = clone_labels < 0
    clone_labels[mask] = 0
    loss = loss_func(logits, clone_labels, reduction='none')

    #loss为nan或者inf的mask
    inf_mask = torch.logical_not(torch.isinf(loss))
    nan_mask = torch.logical_not(torch.isnan(loss))
    outlier_maks = inf_mask * nan_mask
    
    mask = mask*outlier_maks

    size = len(clone_labels)
    label_mask = np.ones(size)

    label_mask[mask.detach().cpu().numpy()] = 0

    valid_num = np.sum(label_mask)

    if valid_num == 0:
        mul = torch.tensor(0.0)
    else:
        mul = torch.tensor(1.0 / valid_num)
    full_mask = torch.FloatTensor(label_mask).to(logits.device)
    loss = loss * full_mask
    loss[torch.isnan(loss)]=0.0
    # 人工给样本加权重，只对留存下来的样本算 loss 均值
    loss = loss.sum() * mul
    return loss

def compute_kl_loss(probabilities, a=5):
    batch_size = probabilities.shape[0]
    p, q = torch.split(probabilities, batch_size//2, dim = 0)

    # You can choose whether to use function "sum" and "mean" depending on your task
    p_loss = F.kl_div(torch.log(p), q, reduction='sum')
    q_loss = F.kl_div(torch.log(q), p, reduction='sum')

    mul = torch.tensor(1.0 / (batch_size//2))

    p_loss = p_loss* mul
    q_loss = q_loss*mul

    loss = (p_loss + q_loss) / 2
    return loss * a

def calc_semi_loss(probabilities,semi_index, loss_fct, inner_loss_func, device,semi_func=None):
    if semi_func == "pseudo":
        semi_probabilities, semi_labels= semi_supversion_labels(probabilities, semi_index, device=device)
        log_semi_prob= torch.log(semi_probabilities)
        semi_loss = loss_fct(semi_labels, log_semi_prob, loss_func=inner_loss_func)
    elif semi_func == "sharpening":
        semi_probabilities, mean_probabilities = semi_supversion_labels_merge(probabilities, semi_index )
        loss_fn = torch.nn.MSELoss(reduction="None")
        semi_loss = loss_fn(semi_probabilities, mean_probabilities)
        semi_loss = torch.sum(semi_loss, axis=-1)
        semi_loss = torch.mean(semi_loss)
    else:
        raise ValueError("please provide a correction semi func")
    return 0.5*semi_loss
class LinearLayer(nn.Module):
    def __init__(self, input_size, output_size,  hidden_dropout_prob=0.1):
        super().__init__()
        self.dense = nn.Linear(input_size, output_size)
        self.dropout = nn.Dropout(hidden_dropout_prob)
        self.active = nn.ReLU()

    def forward(self, hidden_states):
        hidden_states = self.dense(hidden_states)
        hidden_states = self.active(hidden_states)
        hidden_states = self.dropout(hidden_states)
        return hidden_states

class HierarchicalSoftmax(nn.Module):
    '''
    层次Softmax
    '''
    def __init__(self, num_label, label_transfer_dict=None,device="cuda"):
        super().__init__()
        if label_transfer_dict is not None:
            rev_dict = {}
            for k,v in label_transfer_dict.items():
                if v not in rev_dict:
                    rev_dict[v] = []
                rev_dict[v].append(k)
            transfer_matrix = np.zeros((num_label, num_label))
            for k, v in rev_dict.items():
                transfer_matrix[min(v):max(v)+1, min(v):max(v)+1] = 1.0
        else:
            transfer_matrix = np.ones((num_label,num_label))
        self.transfer_matrix = torch.FloatTensor(transfer_matrix)
        self.transfer_matrix = self.transfer_matrix.to(device=device)

    def forward(self,logits_in):
        #首先对 logits计算exp，模型softmax的计算过程，但是这里 不是整行归一化，而是对分属于同一上层分类进行归一化
        logits = logits_clamp(logits_in)
        logits = torch.exp(logits)

        #这里计算每个exp后的logits对应的归一化分母
        weight_logits = torch.mm(logits, self.transfer_matrix)

        #归一化操作
        logits = torch.div(logits, weight_logits)

        return logits

class TreeLabel(object):
    def __init__(self, label_tree, device):
        self.tree_to_list, self.layer_num, self.label_to_layer, self.num_labels,\
            self.label_to_index, self.index_to_label, self.label_reflect_dict = self.parse_label_tree(label_tree)
        self.device = device
        self.transfer_matrix_lst = self.make_logit_transfer_matrix()
        self.hierarchical_softmax_lst = self.make_hierarchical_softmax()

    def __call__(self, label, full_layer=False):
        label_index = [-1] * self.layer_num
        label_layer = -1
        if not full_layer:
            label_layer = self.label_to_layer.get(label, -1)
        else:
            for i in range(self.layer_num):
                if label in self.label_to_index[i]:
                    label_layer = i
        # if label_layer == -1:
        #     raise ValueError("Please provide a label inclued in your hierarchical tree")
        if label_layer != -1:
            index = self.label_to_index[label_layer][label]
            label_index[label_layer] = index

            for i in range(label_layer-1, -1, -1):
                index = self.label_reflect_dict[i][index]
                label_index[i] = index
        labels = [self.index_to_label[i].get(label_index[i], label_index[i]) for i in range(len(label_index))]
        return label_index, labels
    
    def make_label_tensor(self, labels, full_layer=False):
        out_labels = [[] for i in range(self.layer_num)]
        for label in labels:
            label_index, _ = self.__call__(label, full_layer)
            for i in range(self.layer_num):
                out_labels[i].append(int(label_index[i]))
        for i in range(self.layer_num):
            label = out_labels[i]
            label = torch.tensor(label)
            label = label.to(device=self.device)
            out_labels[i] = label
        return out_labels
    
    def get_num_labels(self):
        return self.num_labels
    
    def get_label_transfer(self):
        return self.label_reflect_dict

    def get_transfer_matrix(self, i=None):
        if i == None:
            return self.transfer_matrix_lst
        elif int(i) >= len(self.transfer_matrix_lst):
            raise ValueError("Have exceeded the max length of transfer matrix")
        return self.transfer_matrix_lst[int(i)]

    def get_hierarchcal_softmax(self, i=None):
        if i == None:
            return self.hierarchical_softmax_lst
        elif int(i) >= len(self.hierarchical_softmax_lst):
            raise ValueError("Have exceeded the max length of hierarchical softmax matrix")
        return self.hierarchical_softmax_lst[int(i)]

    def make_logit_transfer_matrix(self):
        transfer_matrix_lst = []
        for i in range(len(self.num_labels)-1):
            num_rough, num_fine = self.num_labels[i], self.num_labels[i+1]
            hier_label_dict = self.label_reflect_dict[i]
            transfer_matrix=np.zeros((num_rough,num_fine))
            for key,value in hier_label_dict.items():
                transfer_matrix[int(value), int(key)]=1.0
            transfer_matrix = torch.FloatTensor(transfer_matrix)
            transfer_matrix = transfer_matrix.to(device=self.device)
            transfer_matrix_lst.append(transfer_matrix)
        return transfer_matrix_lst

    def make_hierarchical_softmax(self):
        hierarchical_softmax_lst = []
        pre_label_dict = None
        for i in range(self.layer_num):
            hierarchical_softmax_lst.append(HierarchicalSoftmax(self.num_labels[i], pre_label_dict, device=self.device))
            if i < self.layer_num-1:
                pre_label_dict = self.label_reflect_dict[i]
        return hierarchical_softmax_lst
    
    def _parse_label_tree(self, label_tree, pre_labels, result):
        for value in label_tree:
            current_labels = pre_labels[:]
            if isinstance(value, list):
                current_labels = pre_labels[:]
                main_label = value[0]
                sub_label =  value[1]
                current_labels.append(main_label)
                self._parse_label_tree(sub_label, current_labels, result)
            else:
                current_labels.append(value)
                result.append(current_labels)
        return result

    def parse_label_tree(self, label_tree):
        tree_to_list = self._parse_label_tree(label_tree, [], [])
        layer_num = max([len(lst) for lst in tree_to_list])

        #构建字典，分配每一个label对应的layer
        label_to_layer = {}
        for lst in tree_to_list:
            for i in range(len(lst)):
                label = lst[i]
                label_to_layer[label] = i

        
        #将每个label标签体系扩展到layer_num的长度
        for record in tree_to_list:
            while len(record) < layer_num:
                record.append(record[-1])

        #为层次分类构建 num_labels 和 label_reflect_dict
        num_labels = [0] * layer_num
        label_to_index = [{} for i in range(layer_num)]
        index_to_label = [{} for i in range(layer_num)]
        label_reflect_dict = [{} for i in range(layer_num-1)]

        for lst in tree_to_list:
            for i in range(len(lst)):
                label = lst[i]
                if label not in label_to_index[i]:
                    label_to_index[i][label] = num_labels[i]
                    index_to_label[i][num_labels[i]] = label
                    num_labels[i] += 1

        for lst in tree_to_list:
            for i in range(len(lst) - 1):
                label, sub_label = lst[i], lst[i+1]
                sub_label_index = label_to_index[i+1][sub_label]
                label_index = label_to_index[i][label]
                label_reflect_dict[i][sub_label_index] = label_index
        return tree_to_list, layer_num, label_to_layer, num_labels, label_to_index, index_to_label, label_reflect_dict            

class HierarchicalMultiLayers(nn.Module):
    def __init__(self,  num_labels, input_size=768, hidden_size = 768, hidden_dropout_prob=0.1):
        super().__init__()

        self.num_labels = num_labels

        """
        分别从粗分类开始往细分类
        """
        upper_layer_size = 0
        for i in range(len(self.num_labels)):
            layer_linear_name = "hc_linear_{}".format(i)
            layer_classifier_name = "hc_classifier_{}".format(i)
            linear = LinearLayer(input_size + upper_layer_size, hidden_size, hidden_dropout_prob)
            classifier = nn.Linear(input_size + hidden_size + upper_layer_size, self.num_labels[i])
            setattr(self, layer_linear_name, linear)
            setattr(self, layer_classifier_name, classifier)
            upper_layer_size = hidden_size
        
    def forward(self, hidden_states):
        upper_layer = None
        for i in range(len(self.num_labels)):
            layer_linear_name = "hc_linear_{}".format(i)
            layer_classifier_name = "hc_classifier_{}".format(i)
            layer_linear  = getattr(self, layer_linear_name)
            layer_classifier = getattr(self, layer_classifier_name)
            input_tensor = hidden_states
            if upper_layer is not None:
                #input_tensor 就是上一层传给下一层的向量，这里需要赋值给 upper_layer
                input_tensor = torch.cat((hidden_states, upper_layer), 1)
            input_tensor = layer_linear(input_tensor)

            pre_out_tensor = torch.cat((hidden_states, input_tensor), 1)
            if upper_layer is not None:
                pre_out_tensor = torch.cat((pre_out_tensor, upper_layer), 1)
            logits = layer_classifier(pre_out_tensor)

            upper_layer = input_tensor

            logits_name = "hc_logit_{}".format(i)
            setattr(self, logits_name, logits)


class HierarchicalMultiClassifierNetwork(nn.Module):
    '''
    输出的内容为
    result:{
        layer_loss,
        hierarchical_loss,
        loss: layer_loss + hierarchical_loss，
        logit_n : n代表对应的层的logit,
        logit: 最后一层的logit,
        probabilities: 最后一层最细类别的概率值,
        preds: 二维列表， 从左往右分别是每一层的预测label
    }
    '''
    def __init__(self,
                    hier_label_tree,
                    hidden_dropout_prob = 0.1,
                    input_size=768, 
                    hidden_size=768, 
                    loss_weights = None,
                    semi_func=None,
                    use_focal_loss=False,
                    use_kl_loss=False,
                    device="cuda"):
        super().__init__()
        self.label_tree = TreeLabel(hier_label_tree, device)
        self.num_labels = self.label_tree.get_num_labels()
        self.hier_share_layer = HierarchicalMultiLayers(self.num_labels, 
                                                    input_size, 
                                                    hidden_size=hidden_size, 
                                                    hidden_dropout_prob=hidden_dropout_prob)
        self.hier_layer = len(self.num_labels)
        self.loss_fct = classification_loss
        self.device = device
        self.loss_weights = loss_weights
        if loss_weights is None:
            self.loss_weights = [1.0] * self.hier_layer
        self.inner_loss_func = nn.functional.nll_loss
        self.use_focal_loss = use_focal_loss
        if use_focal_loss:
            self.inner_loss_func = FocalLoss(0.25)
        self.use_kl_loss = use_kl_loss
        self.semi_func = semi_func
        self.softmax = nn.Softmax(dim=1)

    def calc_layer_loss(self, current_labels, do_train, semi_index=None):
        result = {}
        result["layer_loss_dict"] = {}
        layer_loss = 0.0
        #输出各个层次的预测值
        hc_pred = []
        for i in range(self.hier_layer):
            logits_name = "hc_logit_{}".format(i)   
            logits = getattr(self.hier_share_layer, logits_name)
            '''
            保存logit,并且保留最细的作为初始logit
            '''
            result[logits_name] = logits

            #计算 预测的结果
            current_pred =torch.argmax(logits, dim=1).cpu().numpy()
            current_pred = [self.label_tree.index_to_label[i].get(pred, pred) for pred in current_pred]
            hc_pred.append(current_pred)
            
            probabilities = self.softmax(logits)
            if self.semi_func and semi_index is not None and len(semi_index) > 0:
                semi_loss = calc_semi_loss(probabilities,semi_index, self.loss_fct, self.inner_loss_func, self.device,semi_func=self.semi_func)
                layer_loss = layer_loss + semi_loss
                result["layer_loss_dict"]["semi_loss{}".format(i)] = semi_loss
            if i ==  self.hier_layer-1:
                result["logits"] = logits
                result["probabilities"] = probabilities
            if self.use_kl_loss and do_train:
                cur_kl_loss = compute_kl_loss(probabilities)
                result["layer_loss_dict"]["kl_loss{}".format(i)] = cur_kl_loss
                layer_loss = layer_loss + cur_kl_loss
            if current_labels != None:
                if self.use_focal_loss:
                    per_layer_loss = self.loss_weights[i] * self.loss_fct(current_labels[i], probabilities, loss_func=self.inner_loss_func)
                else:
                    log_prob= torch.log(probabilities)
                    per_layer_loss = self.loss_weights[i] * self.loss_fct(current_labels[i], log_prob, loss_func=self.inner_loss_func)
                layer_loss = layer_loss + per_layer_loss
                result["layer_loss_dict"]["layer_loss_{}".format(i)] = per_layer_loss
        result["pred"] = hc_pred
        return layer_loss, result

    #计算层次LOSS
    def calc_hierarchical_loss(self, current_labels, do_train, semi_index=None):
        result = {}
        result["hier_loss_dict"] = {}
        hc_pred = []
        global_prob = None
        hier_loss = 0.0
        for i in range(self.hier_layer):
            logits_name = "hc_logit_{}".format(i)   
            logits = getattr(self.hier_share_layer, logits_name)
            result[logits_name] = logits
            hier_softmax = self.label_tree.get_hierarchcal_softmax(i=i)
            hier_prob = hier_softmax(logits)
            if i == 0:
                global_prob = hier_prob
            else:
                global_prob = global_prob * hier_prob

            #以层次分类LOSS为主, 结果为层次loss作为最后的结果
            current_pred = torch.argmax(global_prob, dim=1).cpu().numpy()
            current_pred = [self.label_tree.index_to_label[i].get(pred, pred) for pred in current_pred]
            hc_pred.append(current_pred)
            if i == self.hier_layer -1:
                result["logits"] = global_prob
                result["probabilities"] = global_prob

            if self.use_kl_loss and do_train:
                cur_kl_loss = compute_kl_loss(global_prob)
                result["hier_loss_dict"]["kl_loss{}".format(i)] = cur_kl_loss
                hier_loss = hier_loss + cur_kl_loss

            if self.semi_func and semi_index is not None and len(semi_index) > 0:
                semi_loss = calc_semi_loss(global_prob, semi_index, self.loss_fct, self.inner_loss_func, self.device,semi_func=self.semi_func)
                hier_loss = hier_loss + semi_loss
                result["hier_loss_dict"]["semi_loss{}".format(i)] = semi_loss

            if current_labels is not None:
                if self.use_focal_loss:
                    per_hier_loss = self.loss_fct(current_labels[i], global_prob, loss_func=self.inner_loss_func)
                else:
                    log_prob= torch.log(global_prob)
                    per_hier_loss = self.loss_fct(current_labels[i], log_prob, loss_func=self.inner_loss_func)
                hier_loss = hier_loss + per_hier_loss
                result["hier_loss_dict"]["hier_loss_{}".format(i)] = per_hier_loss
            if i < self.hier_layer -1:
                next_transfer_matrix = self.label_tree.get_transfer_matrix(i=i)
                global_prob = torch.mm(global_prob, next_transfer_matrix)

        result["pred"] = hc_pred
        return hier_loss, result
    
    def get_semi_index(self, labels, semi_label="semi"):
        semi_index = []
        for i, label in enumerate(labels):
            if label == semi_label:
                semi_index.append(i)
        return torch.tensor(semi_index).to(self.device)

    def forward(self, hidden_states, labels=None, func_name=None, do_train=True):

        #准备
        semi_index = None
        #构建hmlm的层次结构
        self.hier_share_layer(hidden_states)
        #计算新的labels，此处为list
        current_labels = None
        if labels != None:
            current_labels = self.label_tree.make_label_tensor(labels, full_layer=True)
            if self.semi_func:
                semi_index = self.get_semi_index(labels)
        if func_name != None:
            func_name = func_name.lower()

        result= {}
        if func_name == None or func_name == "hmlc":
            layer_loss, layer_result  = self.calc_layer_loss(current_labels, do_train, semi_index)
            result = layer_result
            result["layer_loss"] = layer_loss
            result["hier_loss"] = 0.0
        elif func_name == "hmlc_global": 
            hierarchical_loss, hierarchical_result = self.calc_hierarchical_loss(current_labels, do_train, semi_index)
            result = hierarchical_result
            result["layer_loss"] = 0.0
            result["hier_loss"] = hierarchical_loss        
        elif func_name == "hmlc_global_all":
            layer_loss, layer_result  = self.calc_layer_loss(current_labels)
            hierarchical_loss, hierarchical_result = self.calc_hierarchical_loss(current_labels, do_train, semi_index)
            result = hierarchical_result
            result["layer_loss"] = layer_loss
            result["hier_loss"] = hierarchical_loss     

        result["loss"] = result["layer_loss"] + result["hier_loss"]

        return result

if __name__ == "__main__":
    """
    构建服从不同正态分布的代码
    """
    print("-" * 100)
    print("first build random normal data")
    import random
    from tqdm import tqdm
    import sys

    func_name = sys.argv[1]
    def gen_random_normal_data(i, label, num):
        random_data = np.random.normal(i, 1, [num,768])
        data = []
        for j in range(num):
            data.append([random_data[j], label])      
        return data 
        
    hierarchical_tree = [
                ["涉赌", ["涉赌违规", "涉赌正常"]],
                ["色情", ["强色情", "弱色情"]]
                ]
    labels = ["涉赌正常", "涉赌违规", "弱色情", "强色情"]
    train_num, test_num = 1000*64, 100*64
    train_data = []
    test_data = []
    for i in range(4):
        train_data += gen_random_normal_data(i, labels[i], train_num)
        test_data += gen_random_normal_data(i, labels[i], test_num)

    random.shuffle(train_data)

    train_device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")

    '''
    evalute的代码
    '''
    def evalute(test_data, model, device):
        print("~" * 100)
        print("begin to evalute")
        model.eval()
        preds= []
        true_labels = []
        with torch.no_grad():
            torch.cuda.empty_cache()
            input_tensor = []
            labels = []
            for record in test_data:
                input_tensor.append(record[0])
                labels.append(record[1])
                if len(input_tensor) == batch_size:
                    torch.cuda.empty_cache()
                    optim.zero_grad()
                    result = model(torch.FloatTensor(input_tensor).to(device), labels, func_name=func_name)
                    true_labels += labels
                    preds += result["pred"][-1]
                    input_tensor = []
                    labels = []
        assert len(true_labels) == len(preds)
        accuracy = [1 if true_labels[i] == preds[i] else 0 for i in range(len(true_labels))]
        return sum(accuracy) / float(len(accuracy))
    """
    训练代码
    """
    print("-" * 100)
    print("then train and valid")
    model = HierarchicalMultiClassifierNetwork(hierarchical_tree, device=train_device)
    model = model.to(train_device)
    epochs = 10
    batch_size = 64
    batch_num = 0
    input_tensor, labels = [], []
    optim = torch.optim.AdamW(model.parameters(), lr=5e-5)

    for i in range(epochs):
        model.train()
        torch.cuda.empty_cache()
        for record in tqdm(train_data):
            input_tensor.append(record[0])
            labels.append(record[1])
            if len(input_tensor) == batch_size:
                torch.cuda.empty_cache()
                optim.zero_grad()
                result = model(torch.FloatTensor(input_tensor).to(train_device), labels, func_name=func_name)
                loss  = result["loss"]
                loss.backward()
                optim.step()
                input_tensor = []
                labels = []
        accuracy = evalute(test_data, model, train_device)
        print(accuracy)
