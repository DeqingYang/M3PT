import torch
from itrl.model.short_text.classifier.bert_text_model import BertTextModel

class BertTextPredictor(object):
    def __init__(self, model_weight_path, device, config=None):
        self.device = device
        self.model = BertTextModel.from_pretrained(model_weight_path, device, config)
        self.config = self.model.config
        self.model.eval()

    def __call__(self, querys):
        result = []
        if isinstance(querys, str):
            querys = [querys]
        #首先计算取出pred和probability
        with torch.no_grad():
            response = self.model({"querys":querys}, do_train=False)
            multi_task_result = response.multi_task_result
            for i in range(len(querys)):
                record = {"query": querys[i]}
                for task_name in self.config["tasks"]:
                    record[task_name] = {}
                    record[task_name]["probability"] = list(map(float, multi_task_result[task_name]["probabilities"][i]))
                    record[task_name]["predicate"] = multi_task_result[task_name]["pred"][-1][i]
                for task_name in self.config.get("regression_tasks", {}):
                    record[task_name] = {}
                    record[task_name]["probability"] = multi_task_result[task_name]["probability"][i]
                result.append(record)
        return result