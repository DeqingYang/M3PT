import torch
import collections
import os
from transformers import BertTokenizer

import logging
logger = logging.getLogger(__name__)

class ShieldBertTokenizer(object):
    def __init__(self,
                vocab_dir,
                model="CHAR_BERT",
                use_person_feature=False,
                person_config={},
                do_lower_case=True,
                do_basic_tokenize=True,
                never_split=None,
                unk_token="[UNK]",
                sep_token="[SEP]",
                pad_token="[PAD]",
                cls_token="[CLS]",
                mask_token="[MASK]",
                tokenize_chinese_chars=True,
                strip_accents=None,
                **kwargs):
        vocab_file = self.get_vocab_file(vocab_dir)
        self.do_lower_case = do_lower_case
        self.use_person_feature = use_person_feature
        self.model = model
        self.cls_token = cls_token
        self.pad_token = pad_token
        self.sep_token = sep_token
        self.unk_token = unk_token
        self.mask_token = mask_token
        self.bert_tokenizer = BertTokenizer(vocab_file,
                                            do_lower_case=do_lower_case,
                                            do_basic_tokenize=do_basic_tokenize,
                                            never_split=never_split,
                                            unk_token=unk_token,
                                            sep_token=sep_token,
                                            pad_token=pad_token,
                                            cls_token=cls_token,
                                            mask_token=mask_token,
                                            tokenize_chinese_chars=tokenize_chinese_chars,
                                            strip_accents=strip_accents,
                                            **kwargs)

        if use_person_feature:
            if "political_person_mapping_path" not in person_config:
                raise ValueError("{} not in person_config".format("political_person_mapping_path"))
            if "political_person_index_path" not in person_config:
                raise ValueError("{} not in person_config".format("political_person_index_path"))
            if "max_person_length" not in person_config:
                raise ValueError("{} not in person_config".format("max_person_length"))
            political_person_mapping_path, political_person_index_path, max_person_length = \
                person_config["political_person_mapping_path"], person_config["political_person_index_path"], person_config["max_person_length"]
            import jieba
            jieba.initialize() 
            self.person_mapping_dict = self.load_person_mapping_dict(political_person_mapping_path)
            self.person_index_dict = self.load_person_index_dict(political_person_index_path)
            self.max_person_length = max_person_length
            self.PERSON_START_FLAG = '[PS]'
            self.PERSON_END_FLAG = '[PE]'

    def __call__(self, texts, max_length=512, fixed_length=False, truncation=True, padding=True, return_tensors="pt",
                    device="cpu", mlm=False, mlm_probability=0.15):
        result = {}
        texts = self.batch_norm_text(texts)
        if self.use_person_feature:
            texts, person_ids = self.batch_add_person_feature(texts)
            if return_tensors == "pt":
                person_ids = torch.tensor(person_ids).to(device)
            result["person_ids"] = person_ids
        if not isinstance(texts, (str, list, tuple)):
            raise ValueError("input texts must be a type in (str, list, tuple)")
        if isinstance(texts, str):
            texts = [texts]
        input_ids, token_type_ids, attention_masks = [], [], []
        for text in texts:
            input_id, token_type_id, attention_mask = self.text_to_ids(text, max_length, truncation)
            input_ids.append(input_id)
            token_type_ids.append(token_type_id)
            attention_masks.append(attention_mask)
        if padding is True:
            input_ids, token_type_ids, attention_masks = self.padding(input_ids, token_type_ids, attention_masks, fixed_length=fixed_length)
        if return_tensors == "pt":
            input_ids = torch.tensor(input_ids)
            token_type_ids = torch.tensor(token_type_ids)
            attention_masks = torch.tensor(attention_masks)
        if mlm:
            input_ids, mlm_labels = self.mask_input_ids(input_ids, mlm_probability=mlm_probability)
            result["mlm_labels"] = mlm_labels.to(device)
        result["input_ids"], result["token_type_ids"], result["attention_masks"] = \
                input_ids.to(device), token_type_ids.to(device), attention_masks.to(device)
        return result

    def get_vocab_file(self, vocab_dir):
        if os.path.isfile(vocab_dir):
            return vocab_dir
        elif os.path.isdir(vocab_dir):
            vocab_file = os.path.join(vocab_dir, "vocab.txt")
            if os.path.exists(vocab_file):
                return vocab_file
            else:
                raise ValueError("vocab.txt must contained in {}".format(vocab_dir))
        else:
            raise ValueError("{} not exists".format(vocab_dir))

    def load_vocab(self, vocab_file):
        return self.bert_tokenizer.load_vocab(vocab_file)

    def char_bert_tokenize(self, text):
        if text is None or len(text) == 0:
            return ""
        text = self.norm_text(text)
        if self.do_lower_case:
            text = text.lower()
        tokens = list(text)
        tokens = self.drop_multi_blank(tokens)
        if self.use_person_feature:
            tokens = self.extract_feature(tokens)
        return tokens

    def bert_tokenize(self, text):
        tokens = self.bert_tokenizer.tokenize(text)
        text = "\t".join(tokens)
        text = text.replace("[\tps\t]", "[PS]").replace("[\tpe\t]", "[PE]")
        tokens = text.split("\t")
        return tokens

    def id_bert_tokenize(self, text):
        tokens = text.split(" ")
        return tokens

    def tokenize(self, text):
        if self.model == "BERT":
            return self.bert_tokenize(text)
        elif self.model == "CHAR_BERT":
            return self.char_bert_tokenize(text)
        elif self.model == "ID_BERT":
            return self.id_bert_tokenize(text)
        else:
            raise ValueError("in __call__, only support model BERT|CHAR_BERT|ID_BERT")

    def drop_multi_blank(self, tokens):
        processed_tokens = []
        if not tokens:
            return processed_tokens
        pre_token = ""
        for token in tokens:
            if pre_token == " " and token == " ":
                continue
            processed_tokens.append(token)
            pre_token = token
        return processed_tokens

    def convert_tokens_to_ids(self, tokens):
        return self.bert_tokenizer.convert_tokens_to_ids(tokens)

    def convert_ids_to_tokens(self, ids):
        return self.bert_tokenizer.convert_ids_to_tokens(ids)

    def text_to_ids(self, text, max_length, truncation):
        input_id_a, input_id_b = None, None
        if isinstance(text, str):
            tokens_a = self.tokenize(text)
            input_id_a = self.convert_tokens_to_ids(tokens_a)
            if len(input_id_a) > max_length - 2 and truncation:
                input_id_a = input_id_a[:(max_length - 2)]
        elif isinstance(text, list):
            tokens_a, tokens_b = self.tokenize(text[0]), self.tokenize(text[1])
            input_id_a, input_id_b = self.convert_tokens_to_ids(tokens_a), self.convert_tokens_to_ids(tokens_b)
            pair_length = len(input_id_a) + len(input_id_b)
            if pair_length > max_length - 3 and truncation:
                pair_truncate_rsult = self.bert_tokenizer.truncate_sequences(input_id_a, 
                                                                            input_id_b, 
                                                                            pair_length - max_length +3)
                input_id_a, input_id_b = pair_truncate_rsult[0], pair_truncate_rsult[1]

        input_id = [self.convert_tokens_to_ids(self.cls_token)] + input_id_a + [self.convert_tokens_to_ids(self.sep_token)]
        token_type_id = [0 for i in range(len(input_id))]
        if input_id_b is not None:
            input_id += input_id_b + [self.convert_tokens_to_ids(self.sep_token)]
            token_type_id += [1 for i in range(len(input_id_b))] + [1]
        attention_mask = [1 for i in range(len(input_id))]
        assert len(input_id) == len(token_type_id)
        assert len(input_id) == len(attention_mask)
        return input_id, token_type_id, attention_mask

    def padding(self, input_ids, token_type_ids, attention_masks, fixed_length=False):
        if fixed_length:
            max_length = fixed_length
        else:
            max_length = max([len(input_id) for input_id in input_ids])
        padding_id = self.convert_tokens_to_ids(self.pad_token)
        for i in range(len(input_ids)):
            while len(input_ids[i]) < max_length:
                input_ids[i].append(padding_id)
                token_type_ids[i].append(padding_id)
                attention_masks[i].append(padding_id)
            input_ids[i] = input_ids[i][:max_length]
            token_type_ids[i] = token_type_ids[i][:max_length]
            attention_masks[i] = attention_masks[i][:max_length]
            assert len(input_ids[i]) == max_length
            assert len(token_type_ids[i]) == max_length
            assert len(attention_masks[i]) == max_length
        return input_ids, token_type_ids, attention_masks

    def norm_text(self, text):
        if not text:
            return ""
        text = text.replace('\t', '')
        text = ''.join([' ' if ord(c) < 20 else c for c in text])
        return text
    
    def batch_norm_text(self, texts):
        if isinstance(texts, str):
            texts = self.norm_text(texts)
        elif isinstance(texts, (list, tuple)):
            for i in range(len(texts)):
                if isinstance(texts, str):
                    texts[i] = self.norm_text(texts[i])
                elif isinstance(texts[i], (list, tuple)):
                    for j in range(len(texts[i])):
                        texts[i][j] = self.norm_text(texts[i][j])
        else:
            raise ValueError("can not support type {}".format(type(texts)))
        return texts

    def load_person_mapping_dict(self, dict_file):
        res = dict()
        for line in open(dict_file):
            arr = line.strip().split('\t')
            if len(arr) == 2:
                res[arr[0]] = arr[1]
        logger.info("in_file:{} dict size:{}".format(dict_file, len(res)))
        return res

    def load_person_index_dict(self, in_file):
        res = {}
        index = 0
        for line in open(in_file):
            res[line[:-1]] = index
            index += 1
        logger.info("in_file:{} num:{}".format(in_file, len(res)))
        return res

    def batch_add_person_feature(self, texts):
        if isinstance(texts, str):
            text, person_id = self.add_person_feature(texts)
            return text, person_id
        elif isinstance(texts, (list, tuple)):
            out_texts, out_person_ids = [], []
            for text in texts:
                if isinstance(text, str):
                    text, person_id = self.add_person_feature(text)
                    out_texts.append(text)
                    out_person_ids.append(person_id)
                elif isinstance(text, (list, tuple)):
                    if len(text) != 2:
                        raise ValueError("single input text only can be single or pair")
                    text[0], person_ids_a = self.add_person_feature(text[0])
                    text[1], person_ids_b = self.add_person_feature(text[1])
                    person_b_index = 0
                    person_ids = person_ids_a[:]
                    for i in range(len(person_ids)):
                        if person_ids[i] != 0:
                            continue
                        person_ids[i] = person_ids_b[person_b_index]
                        person_b_index += 1
                    out_texts.append(text)
                    out_person_ids.append(person_ids)
            return out_texts, out_person_ids
        else: 
            raise ValueError("in batch_add_person_feature, type of texts: {} cann't support".format(type(texts)))

    def add_person_feature(self, text, is_paddle_segment=True, start_flag='[PS]', end_flag='[PE]'):
        if not text:
            return ""
        import jieba
        text_cut_list = jieba.cut(text, use_paddle=is_paddle_segment)
        result, person_list = [], []
        for ele in text_cut_list:
            if ele in self.person_mapping_dict:
                result += [start_flag, self.person_mapping_dict[ele], end_flag]
                person_list.append(ele)
            else:
                result.append(ele)
        tokens_person = person_list[:self.max_person_length]
        tokens_person += ['[PAD]'] * (self.max_person_length - len(tokens_person))
        person_ids = [self.person_index_dict[t] if t in self.person_index_dict else 0 for t in tokens_person]
        assert len(person_ids) == self.max_person_length
        return "".join(result), person_ids

    def extract_feature(self, tokens, start_flag='[PS]', end_flag='[PE]'):
        text = "".join(tokens)
        # extract person info from text tokens
        tokens, ps_index_lst, pe_index_lst = self.modify_tokens_for_person(text, start_flag, end_flag)
        for index in ps_index_lst:
            tokens[index] = start_flag
        for index in pe_index_lst:
            tokens[index] = end_flag
        return tokens

    def modify_tokens_for_person(self, text, start_flag, end_flag):
        '''
        [PS] 习  近  平 [PE] 的 年  龄
        '''
        text = text.replace('[ps]', '[PS]').replace('[pe]', '[PE]')
        ps_index_lst = []
        pe_index_lst = []
        pos_s = text.find(start_flag)
        pos_e = text.find(end_flag)
        while pos_s != -1 and pos_e != -1 and pos_s < pos_e:
            #[PS]
            ps_index_lst.append(pos_s)
            text = text.replace(start_flag, ' ', 1)

            #[PE],ps需要在pe的前面
            pos_e = text.find(end_flag)
            text = text.replace(end_flag, ' ', 1)
            pe_index_lst.append(pos_e)

            pos_s = text.find(start_flag)
            pos_e = text.find(end_flag)
        return list(text), ps_index_lst, pe_index_lst

    def mask_input_ids(self, input_ids, special_tokens_mask=None, mlm_probability=0.15):
        """
        Prepare masked tokens inputs/labels for masked language modeling: 80% MASK, 10% random, 10% original.
        """

        labels = input_ids.clone()
        # We sample a few tokens in each sequence for MLM training (with probability `self.mlm_probability`)
        probability_matrix = torch.full(labels.shape, mlm_probability)

        #将 sep、cls和pad等不mask
        if special_tokens_mask is None:
            special_tokens_mask = [
                self.get_special_tokens_mask(val, already_has_special_tokens=True) for val in labels.tolist()
            ]
            special_tokens_mask = torch.tensor(special_tokens_mask, dtype=torch.bool)
        else:
            special_tokens_mask = special_tokens_mask.bool()
        # import pdb;pdb.set_trace()
        #将sep和cls的token置0，这样后面就不会mask掉

        probability_matrix.masked_fill_(special_tokens_mask, value=0.0)
    
        #通过伯努利方程决定将那些token mask掉, 伯努利方程会将元素 以p的概率置为1
        masked_indices = torch.bernoulli(probability_matrix).bool()
        labels[~masked_indices] = -100  # We only compute loss on masked tokens

        # 80% of the time, we replace masked input tokens with tokenizer.mask_token ([MASK])
        indices_replaced = torch.bernoulli(torch.full(labels.shape, 0.8)).bool() & masked_indices
        input_ids[indices_replaced] = self.convert_tokens_to_ids(self.mask_token)

        # 10% of the time, we replace masked input tokens with random word
        indices_random = torch.bernoulli(torch.full(labels.shape, 0.5)).bool() & masked_indices & ~indices_replaced
        random_words = torch.randint(len(self.bert_tokenizer), labels.shape)
        input_ids[indices_random] = random_words[indices_random]

        # The rest of the time (10% of the time) we keep the masked input tokens unchanged
        return input_ids, labels

    def get_special_tokens_mask(self, token_ids_0, token_ids_1=None, already_has_special_tokens=False):
            tokens_not_mask = set(self.convert_tokens_to_ids([self.sep_token, self.pad_token, self.cls_token, self.unk_token]))
            if already_has_special_tokens:
                if token_ids_1 is not None:
                    raise ValueError(
                        "You should not supply a second sequence if the provided sequence of "
                        "ids is already formatted with special tokens for the model."
                    )
                return list(map(lambda x: 1 if x in tokens_not_mask else 0, token_ids_0))

            if token_ids_1 is not None:
                return [1] + ([0] * len(token_ids_0)) + [1] + ([0] * len(token_ids_1)) + [1]
            return [1] + ([0] * len(token_ids_0)) + [1]