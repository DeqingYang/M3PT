"""PyTorch BERT model. """
import os
import torch
from torch import nn
import torch.utils.checkpoint
from torch.nn import MSELoss
from torch.nn.parameter import Parameter
from transformers import BertModel, PretrainedConfig
from transformers.models.bert.modeling_bert import BertOnlyNSPHead, BertOnlyMLMHead
from itrl.model.short_text.classifier.hierarchical_multi_classifer import HierarchicalMultiClassifierNetwork, LinearLayer, classification_loss
from itrl.model.short_text.classifier.shield_tokenizer import ShieldBertTokenizer as BertTokenizer

class SequenceClassifierOutput(object):
    def __init__(self, 
                 loss=None,
                 hidden_states=None, 
                 attentions=None,
                 multi_task_result={}):
        self.loss = loss
        self.hidden_states = hidden_states
        self.attentions = attentions
        self.multi_task_result = multi_task_result


class BertTextModel(nn.Module):
    @classmethod
    def from_pretrained(cls, weights_path, device, config=None):
        ckpt = torch.load(weights_path, map_location=torch.device(device))
        if 'train_config' not in ckpt:
            raise Exception("train config not found in model file!")
        train_config = ckpt['train_config']
        if config is not None:
            train_config = config
        model = BertTextModel(train_config, device, ignore_pretrained_bert=True)
        model.load_state_dict(ckpt['model_state_dict'], strict=False)
        return model

    def __init__(self, config, device, ignore_pretrained_bert=True):
        """
        根据 config dict 初始化模型架构，不加载预训练参数
        """
        super().__init__()
        self.train_config = config
        bert_model_file = config.get('bert_model_file', None)
        self.bert_config = PretrainedConfig.from_pretrained(config["bert_config_file"])
        self.bert = BertModel(self.bert_config)
        self.model = config.get("model", "CHAR_BERT")
        self.device = device
        self.loss_fct = classification_loss
        self.do_pretraining = config.get("do_pretraining", False)
        self.do_mlm = config.get("do_mlm", False)
        self.do_nsp = config.get("do_nsp", False)
        self.do_seq2seq = config.get("do_seq2seq", False)
        self.use_kl_loss = config.get("use_kl_loss", False)
        self.do_semi_train = config.get("do_semi_train", False)
        self.semi_func = False
        if self.do_semi_train:
            self.semi_func=config["semi_config"].get("semi_func", None)
        self.dropout = nn.Dropout(self.bert_config.hidden_dropout_prob)
        self.fixed_length = False
        if self.do_seq2seq:
            self.fixed_length = config.get("max_seq_length", 40)
        #增加人名特征
        self.person_config = config.get("person_config", {})
        self.add_person_feature = self.person_config.get("add_person_feature", False)
        if self.add_person_feature:
            person_size = self.person_config.get("person_size", 21128)
            max_person_length = self.person_config.get("max_person_length", 3)
            person_hidden_size = self.person_config.get("person_hidden_size", 256)
            self.entity_feature = EntityFeature(person_size,
                                                max_person_length,
                                                entity_hidden_size = person_hidden_size,
                                                pad_token_id = self.bert_config.pad_token_id,
                                                hidden_size = self.bert_config.hidden_size,
                                                hidden_dropout_prob = self.bert_config.hidden_dropout_prob)
        self.tokenizer = BertTokenizer(config["model_dir"],
                                       self.model,
                                       self.add_person_feature,
                                       self.person_config)

        #分类任务训练
        for task_name in config.get("tasks", {}).keys():
            hierarchical_classifier = HierarchicalMultiClassifierNetwork(config["tasks"][task_name]["label_tree"], 
                                                                         loss_weights=config["tasks"][task_name].get("loss_weights", None),
                                                                         use_focal_loss=config["tasks"][task_name].get("use_focal_loss", False),
                                                                         use_kl_loss=self.use_kl_loss,
                                                                         semi_func=self.semi_func,
                                                                         device=self.device)
            setattr(self, task_name, hierarchical_classifier)
    
        #回归任务多任务
        for task_name in config.get("regression_tasks", {}).keys():
            regression_task = RegressionTask(self.bert_config.hidden_size)
            setattr(self, task_name, regression_task)

        #预训练
        if self.do_pretraining:
            self.pretrain_task = PretrainTask(self.bert_config, self.loss_fct, do_mlm=self.do_mlm, do_nsp=self.do_nsp)

        #生成任务，用在变体还原上
        if self.do_seq2seq:
            self.seq2seq_task = SequenceToSequenceTask(self.bert_config, config, self.loss_fct, self.tokenizer, device, self.fixed_length)

        self.config = config
        self.init_weights()
        if bert_model_file is not None and not ignore_pretrained_bert:
            print("load bert model from pretrained")
            load_google_bert = self.config.get("load_google_bert", False)
            google_vocab_size = self.config.get("google_vocab_size", 21128)
            if load_google_bert and self.bert_config.vocab_size != google_vocab_size:
                current_vocab_size = self.bert_config.vocab_size
                print("load from google bert and have diff vocab")
                self.bert_config.vocab_size = google_vocab_size
                self.bert = BertModel.from_pretrained(bert_model_file, config=self.bert_config)
                self.bert = replace_embedding(self.bert, current_vocab_size)
                self.bert_config.vocab_size = current_vocab_size
            else:
                self.bert = BertModel.from_pretrained(bert_model_file, config=self.bert_config)
        self.to(device) 

    def forward(self, batch, do_train=True):
        r"""
        labels (:obj:`torch.LongTensor` of shape :obj:`(batch_size,)`, `optional`):
            Labels for computing the sequence classification/regression loss. Indices should be in :obj:`[0, ...,
            config.num_labels - 1]`. If :obj:`config.num_labels == 1` a regression loss is computed (Mean-Square loss),
            If :obj:`config.num_labels > 1` a classification loss is computed (Cross-Entropy).
        """
        #统一的返回结果
        multi_task_result = {}
        return_dict = self.config.get("use_return_dict", False)
        querys = batch["querys"]
        if self.use_kl_loss and do_train:
            querys = querys[:] + querys[:]

        tensor_batch = self.tokenizer(querys, 
                                      max_length=self.config.get("max_seq_length", 40),
                                      fixed_length=self.fixed_length,
                                      truncation=True, 
                                      padding=True, 
                                      return_tensors="pt",
                                      mlm=self.do_mlm,
                                      device=self.device)
        outputs = self.bert(
            tensor_batch["input_ids"],
            attention_mask=tensor_batch["attention_masks"],
            token_type_ids=tensor_batch["token_type_ids"],
            return_dict=return_dict
        )
        pooled_output = outputs[1]
        loss = 0.0

        #预训练模型
        if self.do_pretraining:
            masked_lm_loss, next_sentence_loss= self.pretrain_task(outputs, batch, tensor_batch, multi_task_result)
            pretrain_loss = masked_lm_loss + next_sentence_loss
            loss = loss + pretrain_loss

        #生成任务：seq2seq，主要用在变体还原上
        if self.do_seq2seq:
            seq2seq_loss = self.seq2seq_task(outputs, batch, multi_task_result)
            loss = loss + seq2seq_loss

        pooled_output = self.dropout(pooled_output)

        if self.add_person_feature:
            entity_output = self.entity_feature(pooled_output, tensor_batch["person_ids"])

        #分类任务
        for task_name in self.config.get("tasks", {}).keys():
            hierarchical_classifier = getattr(self, task_name)
            labels = batch.get(task_name, None)
            if labels is not None and self.use_kl_loss and do_train:
                labels = labels[:] + labels[:]
            task_add_person_feature = self.config["tasks"][task_name].get("add_person_feature", False)
            if task_add_person_feature:
                result = hierarchical_classifier(entity_output, labels, self.config["tasks"][task_name]["hierarchical_func_name"], do_train)
            else:
                result = hierarchical_classifier(pooled_output, labels, self.config["tasks"][task_name]["hierarchical_func_name"], do_train)
            loss = loss + result["loss"]
            multi_task_result[task_name] = result

        #回归任务
        for task_name in self.config.get("regression_tasks", {}).keys():
            regression_task = getattr(self, task_name)
            task_add_person_feature = self.config["regression_tasks"][task_name].get("add_person_feature", False)
            labels = batch.get(task_name, None)
            if labels is not None:
                if self.use_kl_loss and do_train:
                    labels = labels[:] + labels[:]
                labels = torch.tensor(labels).to(self.device)
            if task_add_person_feature:
                result = regression_task(entity_output, labels)
            else:
                result = regression_task(pooled_output, labels)
            if labels is not None:
                loss = loss + result["loss"]
            multi_task_result[task_name] = result
        if do_train:
            return loss
        return SequenceClassifierOutput(
            loss=loss,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
            multi_task_result=multi_task_result
        )

    def _init_weights(self, module):
        """ Initialize the weights """
        if isinstance(module, (nn.Linear, nn.Embedding)):
            # Slightly different from the TF version which uses truncated_normal for initialization
            # cf https://github.com/pytorch/pytorch/pull/5617
            module.weight.data.normal_(mean=0.0, std=self.bert_config.initializer_range)
        elif isinstance(module, nn.LayerNorm):
            module.bias.data.zero_()
            module.weight.data.fill_(1.0)
        if isinstance(module, nn.Linear) and module.bias is not None:
            module.bias.data.zero_()

    def init_weights(self):
        """
        Initializes and  weights
        """
        # Initialize weights
        self.apply(self._init_weights)


class EntityFeature(nn.Module):
    def __init__(self,
                entity_size,
                max_entity_length,
                entity_hidden_size=256,
                pad_token_id=0,
                hidden_size=768,
                hidden_dropout_prob=0.1):
        super().__init__()
        self.entity_hidden_size = entity_hidden_size
        self.max_person_length = max_entity_length
        self.person_embedding = nn.Embedding(entity_size, entity_hidden_size, padding_idx=pad_token_id)
        self.linear = LinearLayer(hidden_size, hidden_size, hidden_dropout_prob)
        self.entity_linear = LinearLayer(entity_hidden_size * max_entity_length, hidden_size, hidden_dropout_prob)
        self.add_entity_out_linear =  LinearLayer(entity_hidden_size * max_entity_length + hidden_size, hidden_size, hidden_dropout_prob)
    
    def forward(self, hidden_status, entity_ids):
        #person取id并转换为embedding
        entity_feature = self.person_embedding(entity_ids)
        #将每个样例的person feature concat到一起
        entity_feature = torch.reshape(entity_feature, (-1, self.entity_hidden_size * self.max_person_length))

        pooled_output =  self.linear(hidden_status)   
        #转换后和 pooled_output_transfer concat一起
        entity_feature = self.entity_linear(entity_feature)
        pooled_output = torch.cat((pooled_output, entity_feature), 1)
        #LN dropout linear
        pooled_output = self.add_entity_out_linear(pooled_output)
        return pooled_output
  
class RegressionTask(nn.Module):
    def __init__(self,
                hidden_size=768):
        super().__init__()
        self.sigmoid = nn.Sigmoid()
        self.classifier = nn.Linear(hidden_size, 1)
        self.loss_fct = classification_loss

    def forward(self, hidden_status, labels=None):
        result = {}
        logit = self.classifier(hidden_status)
        probability = self.sigmoid(logit)
        result["probability"] = probability.view(-1).tolist()
        if labels is not None:
            loss = self.loss_fct(labels.view(-1), probability.view(-1), nn.functional.mse_loss)
            result["loss"] = loss
        return result

class PretrainTask(nn.Module):
    def __init__(self, bert_config, loss_fct, do_mlm=True, do_nsp=False):
        super().__init__()
        self.bert_config = bert_config
        self.loss_fct = loss_fct
        self.do_mlm = do_mlm
        self.do_nsp = do_nsp
        if self.do_mlm:
            self.lm_cls = BertOnlyMLMHead(self.bert_config)
        if self.do_nsp:
            self.nsp_cls = BertOnlyNSPHead(self.bert_config)

    def forward(self, outputs, batch, tensor_batch, multi_task_result):
        multi_task_result["pretrain"] = {}
        masked_lm_loss, next_sentence_loss, lm_prediction, seq_relationship= 0.0, 0.0, None, None

        if self.do_mlm:
            sequence_output = outputs[0]
            mlm_labels = tensor_batch.get("mlm_labels", None)
            prediction_scores = self.lm_cls(sequence_output)
            lm_prediction = torch.argmax(prediction_scores, dim=-1).cpu().numpy()
            if mlm_labels is not None:
                # -100 index = padding token
                masked_lm_loss = self.loss_fct(mlm_labels.view(-1), prediction_scores.view(-1, self.bert_config.vocab_size))

        if self.do_nsp:
            pooled_output = outputs[1]
            nsp_labels = batch.get("nsp_labels", None)
            seq_relationship_scores = self.nsp_cls(pooled_output)
            seq_relationship = torch.argmax(seq_relationship_scores, dim=-1).cpu().numpy()

            if nsp_labels is not None:
                nsp_labels = torch.tensor(nsp_labels).to(self.device)
                next_sentence_loss = self.loss_fct(seq_relationship_scores.view(-1, 2), nsp_labels.view(-1))
        multi_task_result["pretrain"]["loss"] = {"masked_lm_loss": masked_lm_loss, 
                                                "next_sentence_loss": next_sentence_loss, 
                                                "pretrain_loss": masked_lm_loss+next_sentence_loss}
        multi_task_result["pretrain"]["lm_prediction"] = lm_prediction
        multi_task_result["pretrain"]["seq_relationship"] = seq_relationship
        return masked_lm_loss, next_sentence_loss


class SequenceToSequenceTask(nn.Module):
    def __init__(self, bert_config, config, loss_fct, tokenizer, device, fixed_length):
        super().__init__()
        self.decoder = BertOnlyMLMHead(bert_config)
        self.config = config
        self.bert_config = bert_config
        self.loss_fct = loss_fct
        self.tokenizer = tokenizer
        self.device = device
        self.fixed_length = fixed_length
        self.drop_tokens = {"[PAD]", "[SEP]", "[CLS]", "[UNK]"}

    def forward(self, outputs, batch, multi_task_result):
        multi_task_result["seq2seq"] = {}
        sequence_output = outputs[0]
        seq2seq_labels = batch.get("correction", None)
        prediction_scores = self.decoder(sequence_output)
        prediction = torch.argmax(prediction_scores, dim=-1).cpu().numpy()
        prediction_zh = [self.tokenizer.convert_ids_to_tokens(record) for record in prediction]
        prediction_zh = ["".join([token for token in record if token not in self.drop_tokens]) for record in prediction_zh]

        multi_task_result["seq2seq"]["prediction"] = prediction
        multi_task_result["seq2seq"]["prediction_zh"] = prediction_zh
        if seq2seq_labels is not None:
            seq2seq_labels_tensor = self.tokenizer(seq2seq_labels, 
                                                  max_length=self.config.get("max_seq_length", 40),
                                                  truncation=True, 
                                                  padding=True, 
                                                  return_tensors="pt",
                                                  device=self.device,
                                                  fixed_length=self.fixed_length)

            loss = self.loss_fct(seq2seq_labels_tensor["input_ids"].view(-1),  prediction_scores.view(-1, self.bert_config.vocab_size))
            multi_task_result["seq2seq"]["loss"] = loss
        return loss

class SequenceLabelingTask(nn.Module):
    def __init__(self):
        pass

    def forward(self):
        pass

def replace_embedding(model, vocab_size, hidden_size=768, pad_token_id=0):
    current_embedding = nn.Embedding(vocab_size, hidden_size, padding_idx=pad_token_id)
    # current_embedding.weight = Parameter(torch.cat([model.embeddings.word_embeddings.weight, model.embeddings.extra_word_embeddings.weight], dim=0))
    model.embeddings.word_embeddings = current_embedding
    return model
