import pandas as pd

def add_dict_value(data_dict, key, value=1):
    if isinstance(value, list):
        if key not in data_dict:
            data_dict[key] = list()
        else:
            data_dict[key].extend(value)
    else:
        if key not in data_dict:
            data_dict[key] = value
        else:
            data_dict[key] += value

def get_full_confusion_matrix(label_dict):
    metric = {}
    for pred_key in label_dict:
        for label_key in label_dict:
            metric["{}_{}".format(label_key, pred_key)]=0
    return metric

def read_result_lines(lines, human_label_index, predict_label_index, label_dict, extra_label_dict):
    metric = get_full_confusion_matrix(label_dict)
    #original_info used for store query, label and pred
    for line in lines:
        human_label = str(line[human_label_index])
        predict_label = str(line[predict_label_index])

        key = "%s_%s" %(human_label, predict_label)
        add_dict_value(metric, key, 1)

        # extra label dict
        if human_label in extra_label_dict:
            cur_human_label = extra_label_dict.get(human_label, human_label)
            cur_predict_label = predict_label
            key = "%s_%s" %(cur_human_label, cur_predict_label)
            add_dict_value(metric, key, 1)

            if predict_label in extra_label_dict:
                cur_predict_label = extra_label_dict.get(predict_label, predict_label)
                key = "%s_%s" %(cur_human_label, cur_predict_label)
                add_dict_value(metric, key, 1)

        if predict_label in extra_label_dict:
            cur_human_label = human_label
            cur_predict_label = extra_label_dict.get(predict_label, predict_label)
            key = "%s_%s" %(cur_human_label, cur_predict_label)
            add_dict_value(metric, key, 1)
    return metric

def get_row_cols(data_dict, label_dict, delim='_'):
    rows = set()
    cols = set()
    for key in data_dict.keys():
        row, col = key.split(delim)
        rows.add(row)
        cols.add(col)
    rows = sorted(rows, key=lambda x:int(label_dict[x]))
    cols = sorted(cols, key=lambda x:int(label_dict[x]))
    return rows, cols

def create_stats_table(metric, label_dict, invalid_row_labels=set(), invalid_col_labels=set()):
    rows, cols = get_row_cols(metric, label_dict)
    
    col_sum = {col:0 for col in cols + ['total']}
    col_matched_vals = {col:0 for col in cols}
    w = ['', 'total'] + cols + ['recall']
    stat = [w]
    for row in rows:
        vals = []
        row_sum = 0
        matched_val = 0
        for col in cols:
            key = "%s_%s" %(row, col)
            val = metric.get(key, 0)

            if col not in invalid_col_labels:
                row_sum += val
            vals.append(val)

            if col == row:
                col_matched_vals[col] = val
                matched_val = val

            if row not in invalid_row_labels:
                col_sum[col] += val
        if row not in invalid_row_labels:
            col_sum["total"] += row_sum

        w = [row, row_sum] + vals + [matched_val * 1.0 / (row_sum + 0.0001)]
        stat.append(w)

    store_excel = []
    for ele in stat:
        store_excel.append(ele)
    store_excel.append(["total"] + [col_sum[col] for col in ['total'] + cols])
    store_excel.append([" ","precision"] + [col_matched_vals[col] * 1.0 / (col_sum[col] + 0.0001) for col in cols])
    df = pd.DataFrame(store_excel, columns= [str(i) for i in range(len(store_excel[0]))])

    return df

def calculate_text_classification_stats(lines, human_label_index, predict_label_index, label_dict, extra_label_dict):
    metric = read_result_lines(lines, human_label_index, predict_label_index, 
        label_dict, extra_label_dict)
    
    invalid_row_labels = set(extra_label_dict.values())
    invalid_col_labels = set(extra_label_dict.values())
    df = create_stats_table(metric, label_dict, invalid_row_labels, invalid_col_labels)

    return df