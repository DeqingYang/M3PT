import torch
import numpy as np
from tqdm import tqdm
from transformers import get_linear_schedule_with_warmup
from sklearn import metrics
from .bert_text_model import BertTextModel

import util.odps_util as odps_util
import util.torch_util as torch_util
from util.metrics import logging_metrics, OSSTensorboardWriter

import os
import logging
logger = logging.getLogger(__name__)

from .text_classification_stats import calculate_text_classification_stats

def label_dict_supplement(label_dict, extra_label_dict):
    for key, value in extra_label_dict.items():
        if value not in label_dict:
            label_dict[value] = len(label_dict)
    return label_dict, extra_label_dict

def evaluate_model(model, validation_loader, config):
    print("Evaluating Model...")
    model.eval()
    evalute_multi_task_result = {}
    loss_lst = []
    ignore_tasks = config.get("ignore_evalute_tasks", {})
    with torch.no_grad():
        torch.cuda.empty_cache()
        for batch in validation_loader:
            result = model(batch, do_train=False)
            loss = result.loss
            loss_value = loss.cpu().numpy()
            loss_lst.append(loss_value)
            #保存每个任务的标签和预测值
            for task_name in config["tasks"]:
                if task_name in ignore_tasks:
                    continue
                if task_name not in evalute_multi_task_result:
                    evalute_multi_task_result[task_name] = {
                        "labels": [],
                        "predictions": [],
                        "probability": [],
                        "loss": [],
                        "loss_detail_dict": {}
                    }

                single_task_ret = result.multi_task_result[task_name]
                evalute_multi_task_result[task_name]["labels"] += batch[task_name]
                evalute_multi_task_result[task_name]["predictions"] += single_task_ret["pred"][-1]
                evalute_multi_task_result[task_name]["loss"].append(single_task_ret["loss"])
                evalute_multi_task_result[task_name]["probability"] += single_task_ret["probabilities"].tolist()

                layer_loss_dict = single_task_ret.get("layer_loss_dict", {})
                for key in layer_loss_dict:
                    if key not in evalute_multi_task_result[task_name]["loss_detail_dict"]:
                        evalute_multi_task_result[task_name]["loss_detail_dict"][key] = []
                    evalute_multi_task_result[task_name]["loss_detail_dict"][key].append(layer_loss_dict[key])

                hier_loss_dict = single_task_ret.get("hier_loss_dict", {})
                for key in hier_loss_dict:
                    if key not in evalute_multi_task_result[task_name]["loss_detail_dict"]:
                        evalute_multi_task_result[task_name]["loss_detail_dict"][key] = []
                    evalute_multi_task_result[task_name]["loss_detail_dict"][key].append(hier_loss_dict[key])

            #加入回归任务的LOSS
            for task_name in config.get("regression_tasks", {}):
                if task_name in ignore_tasks:
                    continue
                if task_name not in evalute_multi_task_result:
                    evalute_multi_task_result[task_name] = {
                        "loss": [],
                        "probability": []
                    }
                single_task_ret = result.multi_task_result[task_name]
                evalute_multi_task_result[task_name]["probability"] += single_task_ret["probability"]
                evalute_multi_task_result[task_name]["loss"].append(single_task_ret["loss"])


            torch.cuda.empty_cache()
        avg_loss = sum(loss_lst) / len(loss_lst)
        evalute_multi_task_result["loss"] = avg_loss

        #计算每个task的混淆矩阵和配置中关心的准召
        for task_name in config["tasks"]:
            if task_name in config.get("ignore_evalute_tasks", {}):
                continue
            labels, predictions = evalute_multi_task_result[task_name]["labels"], evalute_multi_task_result[task_name]["predictions"]
            labels = np.array(labels)
            predictions = np.array(predictions)

            task_model = getattr(model, task_name)
            origin_label_dict = task_model.label_tree.label_to_index[-1]

            #映射字典
            extra_label_dict = config["tasks"][task_name].get("extra_label_dict", {})
            label_dict, extra_label_dict = label_dict_supplement(origin_label_dict.copy(), extra_label_dict)

            #计算auc
            probability = evalute_multi_task_result[task_name]["probability"]
            observe_auc = calc_obverse_auc(labels, probability, origin_label_dict)
            evalute_multi_task_result[task_name]["observe_auc"] = observe_auc

            #计算F1
            cm_df = calculate_text_classification_stats(zip(labels, predictions), 0, 1, label_dict, extra_label_dict)
            macro_p, macro_r, macro_f1 = calc_p_r(cm_df, config["tasks"][task_name], label_dict)
            observe_result = calc_observe_labels_p_r(cm_df, config["tasks"][task_name], label_dict)
            evalute_multi_task_result[task_name]["confusion_matrix"] = cm_df
            evalute_multi_task_result[task_name]["label_dict"] = label_dict
            evalute_multi_task_result[task_name]["macro_p"] = macro_p
            evalute_multi_task_result[task_name]["macro_r"] = macro_r
            evalute_multi_task_result[task_name]["macro_f1"] = macro_f1
            evalute_multi_task_result[task_name]["observe_result"] = observe_result
    return evalute_multi_task_result

def evalute_pretrain(model, validation_loader, config):
    print("Evaluating pretrain...")
    model.eval()
    loss_lst = []
    mask_loss_lst = []
    next_sentence_loss_lst = []
    with torch.no_grad():
        torch.cuda.empty_cache()
        for batch in validation_loader:
            result = model(batch, do_train=False)
            loss  = result.loss
            multi_task_result = result.multi_task_result
            masked_lm_loss =  multi_task_result["pretrain"]["loss"]["masked_lm_loss"]
            next_sentence_loss = multi_task_result["pretrain"]["loss"]["next_sentence_loss"]
            loss_lst.append(loss)
            mask_loss_lst.append(masked_lm_loss)
            next_sentence_loss_lst.append(next_sentence_loss)
    return sum(loss_lst) / len(loss_lst), sum(mask_loss_lst) / len(mask_loss_lst), sum(next_sentence_loss_lst) / len(next_sentence_loss_lst)

def evalute_seq2seq(model, validation_loader, config):
    print("Evaluating seq2seq...")
    model.eval()
    loss_lst = []
    seq2seq_querys = []
    seq2seq_labels = []
    seq2seq_prediction = []
    main_model = model
    if hasattr(model, 'module'):
        main_model = model.module
    with torch.no_grad():
        torch.cuda.empty_cache()
        for batch in validation_loader:
            result = main_model(batch, do_train=False)
            loss = result.loss
            loss_lst.append(loss)
            multi_task_result = result.multi_task_result
            prediction_zh = multi_task_result["seq2seq"]["prediction_zh"]

            seq2seq_querys += batch["querys"]
            seq2seq_labels += batch["correction"]
            seq2seq_prediction += prediction_zh
    
    assert len(seq2seq_querys) == len(seq2seq_labels)
    assert len(seq2seq_querys) == len(seq2seq_prediction)

    num = len(seq2seq_querys)
    triggle_num, triggle_correct, triggle_all_same = 0, 0, 0
    shape_num = 0
    for i in range(num):
        query, correction, prediction = seq2seq_querys[i],  seq2seq_labels[i],  seq2seq_prediction[i]
        #这个是需要召回的数量
        if query != correction:
            shape_num += 1
 
        #这个是触发的数量
        if prediction != query:
            triggle_num += 1
            #触发且正确
            if query != correction:
                triggle_correct += 1
                #触发且完全一致
                if prediction == correction:
                    triggle_all_same += 1
    triggle_rate = triggle_num/float(num)
    triggle_correct_rate = triggle_correct/float(num)
    triggle_recall_rate = triggle_correct/float(shape_num)
    total_same_rate = triggle_all_same/float(shape_num)

    logging_dict = {"triggle_rate": triggle_rate,
    "triggle_correct_rate": triggle_correct_rate,
    "triggle_recall_rate": triggle_recall_rate,
    "total_same_rate": total_same_rate,
    "triggle_num": triggle_num,
    "triggle_correct":triggle_correct,
    "triggle_all_same": triggle_all_same
    }
    return sum(loss_lst) / len(loss_lst), logging_dict

def calc_p_r(df, config, label_dict):
    pre_shift_len, re_shift_len = 2, 1
    cm_array = df.values
    macro_labels = config["calc_macro_labels"].split(",")
    macro_index = [label_dict.get(i,i) for i in macro_labels]
    precisous, recall = 0.0, 0.0
    for i,label_id in enumerate(macro_index):
        label_id = int(label_id)
        precisous += cm_array[-1][pre_shift_len+label_id]
        recall += cm_array[label_id+re_shift_len][-1]
    precisous /= len(macro_index)
    recall /= len(macro_index)
    F1 = 2*precisous*recall/(precisous+recall+ 0.00001)
    return precisous, recall, F1

def calc_observe_labels_p_r(df, config, label_dict):
    pre_shift_len, re_shift_len = 2, 1
    debug_result = {}
    debug_labels = config["observe_labels"].split(",")
    debug_index = [label_dict.get(i,i) for i in debug_labels]
    cm_array = df.values
    for i, index in enumerate(debug_index):
        label = debug_labels[i]
        precisous, recall = 0.0, 0.0
        label_id = int(index)
        precisous = cm_array[-1][pre_shift_len+label_id]
        recall = cm_array[label_id+re_shift_len][-1]
        F1 = 2*precisous*recall/(precisous+recall + 0.00001)
        debug_result[label] = {"precision":precisous, "recall": recall, "f1":F1}
    return debug_result

def calc_obverse_auc(labels, probabilities, label_dict):
    debug_result = {}
    #将label转换为one-hot形式，
    labels_to_num = [int(label_dict.get(i, i)) for i in labels]
    label_flatten = [[0 for i in range(len(label_dict))] for j in range(len(labels_to_num))]
    for i, label in enumerate(labels_to_num):
        label_flatten[i][label] = 1
    label_flatten =  np.array(label_flatten)
    probabilities = np.array(probabilities)

    rev_label_dict = {v:k for k,v in label_dict.items()}
    total_auc = 0.0
    for i in range(len(label_dict)):
        fpr, tpr, thresholds = metrics.roc_curve(label_flatten[:,i], probabilities[:,i])
        auc = metrics.auc(fpr, tpr)
        total_auc += auc
        debug_result[rev_label_dict[i] + "_auc"] = auc
    debug_result["avg_auc"] = total_auc / len(label_dict)
    return debug_result

def run_validation(model, dev_dl, train_config, writer, prefix, i):
    logger.info("---------begin to {}----------------".format(prefix))
    multi_task_result = evaluate_model(model, dev_dl, train_config)
    important_task_names = train_config["important_task_names"].split(",")
    ignore_tasks = train_config.get("ignore_evalute_tasks", {})
    avg_p, avg_r, avg_f1 = 0.0, 0.0, 0.0
    for task_name in train_config["tasks"]:
        if task_name in ignore_tasks:
            continue
        single_result = multi_task_result[task_name]
        sub_prefix = task_name + "_" + prefix
        loss, confusion_matrix, macro_p, macro_r, macro_f1, observe_result, observe_auc = \
            single_result["loss"], single_result["confusion_matrix"], single_result["macro_p"], single_result["macro_r"], \
            single_result["macro_f1"], single_result["observe_result"], single_result["observe_auc"]
        logging_metrics(writer, sub_prefix, i, {"precision": macro_p, "recall": macro_r, "f1": macro_f1, "loss": sum(loss)/len(loss)})
        loss_detail_dict = single_result["loss_detail_dict"]
        loss_detail_dict_flatten = {}
        for key in loss_detail_dict:
            loss_detail_dict_flatten[key] = sum(loss_detail_dict[key]) / len(loss_detail_dict[key])
        logging_metrics(writer, sub_prefix, i, loss_detail_dict_flatten)
        if task_name in important_task_names:
            avg_p += macro_p
            avg_r += macro_r
            avg_f1 += macro_f1
        logger.info("----%s-----precision: %f, recall: %10f, f1: %f----------------" % (sub_prefix, macro_p, macro_r, macro_f1))
        for label in observe_result:
            label_detail = observe_result[label]
            p, r, f1 = label_detail["precision"], label_detail["recall"], label_detail["f1"]
            logging_metrics(writer, sub_prefix + "_detail", i, \
                {label + "_precision": p, label + "_recall": r, label + "_f1": f1})
        logging_metrics(writer, sub_prefix + "_detail", i, observe_auc)

    for task_name in train_config.get("regression_tasks", {}):
        single_result = multi_task_result[task_name]
        loss = single_result["loss"]
        sub_prefix = task_name + "_" + prefix
        logging_metrics(writer, sub_prefix, i, {"loss": sum(loss)/len(loss)})

    return avg_p / len(important_task_names), avg_r / len(important_task_names), avg_f1 / len(important_task_names)

def build_semi_supversion_labels(model, batch, config, threshold=0.99):
    model.eval()
    with torch.no_grad():
        torch.cuda.empty_cache()
        result = model(batch, do_train=False)
        for task_name in config.get("tasks", {}).keys():
            task_labels = []
            task_result = result.multi_task_result[task_name]
            labels, predictions = batch[task_name], task_result["pred"][-1]
            probability = task_result["probabilities"]
            for i in range(len(labels)):
                label = labels[i]
                if label == "semi" and max(probability[i]) > threshold:
                       labels[i] = predictions[i]
            batch[task_name] = labels
    model.train()
    return batch       


def train_bert_text_model(exp_name, dataset, config):
    gpu_count = torch_util.check_gpu()
    has_gpu = True if gpu_count > 0 else False
    device = 'cuda' if has_gpu else 'cpu'
    #pretrain还是finetuning任务
    do_pretraining = config.get("do_pretraining", False)
    #seq2seq任务
    do_seq2seq = config.get("do_seq2seq", False)

    #获取训练参数
    learning_rate = config.get("learning_rate", 2e-5)
    batch_size = config.get("batch_size", 16)
    epoch = config.get("epoch", 10)

    #获取保存中间结果参数
    save_model_dir = config.get("save_model_dir", "./save_model_dir")
    save_model_dir = os.path.join(save_model_dir, exp_name)
    sync_oss_secs = config.get("sync_oss_secs", 300)
    oss_tensorboard_path = config["oss_tensorboard_path"]
    oss_tensorboard_path = os.path.join(oss_tensorboard_path, exp_name)
    validation_interval = config.get("validation_interval", 1000)

    #是否使用预训练的BERT
    ignore_pretrained_bert = config.get("ignore_pretrained_bert", False)
    do_semi_train = config.get("do_semi_train", False)

    #计算训练样本总数
    train_data_num = 0
    partition_needed = config["data_loader"].get("sample_weight", {})
    if len(partition_needed) > 0:
        for partition in partition_needed.keys():
            train_data_num = train_data_num + odps_util.get_table_rows(config["data_loader"]["train_table_name"], partition)
    else:
        train_data_num = odps_util.get_table_rows(config["data_loader"]["train_table_name"])
    print("total data num trained: {}".format(train_data_num))
    if not os.path.exists(save_model_dir):
        os.makedirs(save_model_dir)
    #初始化模型
    if not config.get("from_pretrained", False):
        model = BertTextModel(config, device, ignore_pretrained_bert=ignore_pretrained_bert)
    else:
        print("load from pretrained LM")
        model = BertTextModel.from_pretrained(config["bert_model_file"], device, config=config)
    if gpu_count > 1:
        logger.info("Using data parallel with multi gpu.")
        model = torch.nn.DataParallel(model, device_ids=list(range(gpu_count)))
    #初始化优化器和训练的step
    optim = torch.optim.AdamW(model.parameters(), lr=learning_rate)
    num_warmup_step = int(train_data_num / batch_size)
    num_training_steps = int(train_data_num * epoch / batch_size)
    scheduler = get_linear_schedule_with_warmup(optim, num_warmup_steps=num_warmup_step, 
                                                num_training_steps=num_training_steps)
    model.train()
    best_f1 = -1
    best_loss = np.inf
    with OSSTensorboardWriter(oss_tensorboard_path, 10, sync_oss_secs) as writer:
        pbar = tqdm(dataset.train)
        for i, batch in enumerate(pbar):
            i += 1
            optim.zero_grad()
            result = model(batch)
            loss = result.mean()
            loss.backward()
            optim.step()
            scheduler.step()
            lr = scheduler.get_lr()[0]
            logging_metrics(writer, 'train', i, {"learning_rate": lr, "loss": loss})
            lr = scheduler.get_lr()[0]
            desc = "iter:{},loss:{:.3f},lr:{:.8f}".format(i, loss, lr)
            pbar.set_description(desc)

            is_last_step = i == num_training_steps
            if i % int(validation_interval) == 0 or is_last_step:
                if do_pretraining:
                    evalute_loss, mlm_loss, nsp_loss = evalute_pretrain(model, dataset.validation, config)
                    logging_metrics(writer, 'evalute', i, {"masked_lm_loss": mlm_loss, "next_sentence_loss": nsp_loss, "total_loss":evalute_loss})
                    loss, mlm_loss, nsp_loss = evalute_pretrain(model, dataset.test, config)
                    logging_metrics(writer, 'test', i, {"masked_lm_loss": mlm_loss, "next_sentence_loss": nsp_loss, "total_loss":loss})
                    if evalute_loss < best_loss or is_last_step:
                        best_loss = evalute_loss
                        path = "{}/batch_{}_{}.pth".format(save_model_dir, i, evalute_loss)
                        torch_util.save_model_and_training_state(path, evalute_loss, model)
                elif do_seq2seq:
                    seq2seq_loss, logging_dict = evalute_seq2seq(model, dataset.validation, config)
                    logging_metrics(writer, 'evalute', i, {"seq2seq_loss": seq2seq_loss})
                    logging_metrics(writer, 'evalute', i, logging_dict)


                    seq2seq_loss_test, test_logging_dict = evalute_seq2seq(model, dataset.test, config)
                    logging_metrics(writer, 'test', i, {"seq2seq_loss": seq2seq_loss_test})
                    logging_metrics(writer, 'test', i, test_logging_dict)

                    if seq2seq_loss < best_loss or is_last_step:
                        best_loss = seq2seq_loss
                        path = "{}/batch_{}_{}.pth".format(save_model_dir, i, seq2seq_loss)
                        torch_util.save_model_and_training_state(path, seq2seq_loss, model)
                else:
                    # 以 dev 集合 f1 score 为基准
                    _, _, f1 = run_validation(model, dataset.validation, config, writer, "dev", i)
                    if config.get("do_test", True):
                        run_validation(model, dataset.test, config, writer, "test", i)

                    if f1 > best_f1 or is_last_step:
                        best_f1 = f1
                        path = "{}/batch_{}_{}.pth".format(save_model_dir, i, f1)
                        torch_util.save_model_and_training_state(path, f1, model)
                if is_last_step:
                    break
                model.train()
