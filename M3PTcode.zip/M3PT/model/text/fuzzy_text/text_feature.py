import json

class TextFeature(object):

    def __init__(self, text, with_tone=False):
        from .char_config import stroke_conf, chaizi_conf
        from pypinyin import lazy_pinyin, Style
        self.text = text
        self.is_cn = [ch >= u'\u4e00' and ch <= u'\u9fff' for ch in text]
        # 是否带上音调
        if with_tone:
            self.pinyin = lazy_pinyin(list(text), style=Style.TONE3)
        else:
            self.pinyin = lazy_pinyin(list(text))
        self.chaizi = [chaizi_conf[ch][0] if ch in chaizi_conf else None for ch in text]
        self.stroke = [stroke_conf[ch] if ch in stroke_conf else None for ch in text]
        self.len = len(text)

    def __len__(self):
        return self.len

    def __str__(self):
        return json.dumps([self.text, self.is_cn, self.pinyin, self.chaizi, self.stroke])

    def __repr__(self):
        return self.__str__()

if __name__ == "__main__":
    import sys
    sys.path.insert(0, "../")
    import fuzzy_text.text_feature as text_feature
    print(text_feature.TextFeature("习大大是谁"))