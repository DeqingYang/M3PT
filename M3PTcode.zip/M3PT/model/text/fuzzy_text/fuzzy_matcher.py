from tqdm import tqdm
import logging
logger = logging.getLogger(__name__)

def transform_pinyin(py):
    candidates = [py]
    if py[0] in ('z', 'c', 's') and len(py) > 1:
        if py[1] == 'h':
            candidates.append(py[0] + py[2:])
        else:
            candidates.append(py[0] + "h" + py[1:])
    if py.endswith("ng") and len(py) > 3 and py[-3] in ('i', 'e'):
        candidates.append(py[:-1])
    elif py.endswith('n') and len(py) > 2 and py[-2] in ('i', 'e'):
        candidates.append(py + 'g')
    return candidates


class CorpusNode(object):

    def __init__(self):
        self.text = {}
        self.pinyin = {}
        self.first_letter = {}
        self.match = []

    # 0 exact 1 py 2 first 3 pinyin_alpha 4 shape
    # return -> (next_match_pos, [..(type[], raw)..], nfa_node)
    def match_char(self, i, feature, trace, hanzi_similar):
        txt = feature.text[i]
        py = feature.pinyin[i]
        is_cn = feature.is_cn[i]
        chaizi = feature.chaizi[i]
        stroke = feature.stroke[i]
        nexts = set()
        seen = set()
        if txt in self.text:
            n = self.text[txt]
            nexts.add((i + 1, trace + ((0, txt),), n))
            seen.add(n)
        if is_cn:
            if py in self.pinyin:
                n = self.pinyin[py]
                if n not in seen:
                    nexts.add((i + 1, trace + ((1, py),), n))
                    seen.add(n)

            # 拆字匹配
            han_vote = {}
            j = i
            while j < min(i + 2, feature.len) and feature.is_cn[j]:
                ch = feature.text[j]
                if ch not in hanzi_similar:
                    break
                for han, score in hanzi_similar[ch]:
                    if han in self.text:
                        if han not in han_vote:
                            han_vote[han] = [score, j + 1]
                        else:
                            han_vote[han] = [han_vote[han][0] + score, j + 1]
                j += 1
            for han in han_vote:
                res = han_vote[han]
                if res[0] > 0.5:
                    n = self.text[han]
                    if n not in seen:
                        nexts.add((res[1], trace + ((4, feature.text[i:res[1]]),), n))
                        seen.add(n)
            # 组合字匹配
            cur = [(self, 0, 0)]
            seen_part = set()
            total_stroke = 0 if stroke is None else len(stroke)
            from .char_config import stroke_conf
            while len(cur) > 0 and chaizi is not None and total_stroke > 0:
                next_cur = []
                for k, ch in enumerate(chaizi):
                    if k in seen_part:
                        continue
                    stroke_count = len(stroke_conf.get(ch, ''))
                    for c, current_count, char_count in cur:
                        if ch in c.text:
                            n = c.text[ch]
                            new_count = current_count + stroke_count
                            new_char_count = char_count + 1
                            if n not in seen and new_count / (total_stroke + 0.0) > 0.8:
                                nexts.add((i + 1, trace + ((4, txt),) * new_char_count, n))
                                seen.add(n)
                            seen_part.add(k)
                            next_cur.append((n, new_count, new_char_count))
                cur = next_cur

        else:
            j = i + 1
            while j < feature.len and not feature.is_cn[j]:
                alpha = feature.text[i:j+1]
                if alpha in self.pinyin:
                    n = self.pinyin[alpha]
                    nexts.add((j + 1, trace + ((3, alpha),), n))
                j += 1
            if txt in self.first_letter:
                for n in self.first_letter[txt]:
                    nexts.add((i + 1, trace + ((2, txt),), n))
        return nexts

    def grow_char(self, i, feature, py, sim_py, py_first):
        txt = feature.text[i]
        py = feature.pinyin[i]
        is_cn = feature.is_cn[i]

        nexts = set()
        next_node = None

        if txt in self.text:
            next_node = self.text[txt]
        if is_cn:
            if sim_py:
                transforms = transform_pinyin(py)
            else:
                transforms = [py]
            for p in transforms:
                if p in self.pinyin:
                    next_node = self.pinyin[p]
        if next_node is None:
            next_node = CorpusNode()

        self.text[txt] = next_node
        nexts.add(self.text[txt])
        if is_cn:
            first = py[0]
            for p in transforms:
                if p not in self.pinyin:
                    self.pinyin[p] = next_node
                nexts.add(self.pinyin[p])
                if py_first:
                    if first not in self.first_letter:
                        self.first_letter[first] = set()
                    self.first_letter[first].add(self.pinyin[p])
        return nexts


class FuzzyMatcher(object):

    def __init__(self, corpus):
        from opencc import OpenCC
        self.cc = OpenCC('t2s')
        self.build_index(corpus)

    def parse_corpus_line(self, line):
        parts = line.strip().split("`")
        level = 1
        py = False
        sim_py = False
        py_first = False
        shape = False
        ws_filter = False
        same_filter = False
        alpha_filter = False
        if len(parts) == 0:
            return None, None, None, None, None, None, None, None, None, None
        else:
            word = parts[0].strip()
            norm, _ = self.normalize_string(word)
            if len(norm) == 0:
                return None, None, None, None, None, None, None, None, None, None
            if len(parts) > 1:
                level = int(parts[1])
            sim_types = set(parts[2:])
            if "shape" in sim_types:
                shape = True
            if "py_first" in sim_types:
                py_first = True
            if "py" in sim_types:
                py = True
            if "sim_py" in sim_types:
                sim_py = True
            if 'ws_filter' in sim_types:
                ws_filter = True
            if 'same_filter' in sim_types:
                same_filter = True
            if 'alpha_filter' in sim_types:
                alpha_filter = True

            return norm, level, py, sim_py, py_first, shape, ws_filter, same_filter, alpha_filter, word

    def build_index(self, raw_texts):
        # 清空内存索引
        self.index = CorpusNode()
        self.hanzi_similar = {}
        self.name_feature = {}
        self.seen = set()
        for line in tqdm(raw_texts):
            word, level, py, sim_py, py_first, shape, ws_filter, same_filter, alpha_filter, original_word \
                = self.parse_corpus_line(line)
            if word is None:
                continue
            from .text_feature import TextFeature
            word_feature = TextFeature(word)
            self.add_to_index(word_feature, level, py, sim_py, py_first, shape)
            self.name_feature[word_feature.text] = (word_feature, py, sim_py, py_first, shape,
                                                    ws_filter, same_filter, alpha_filter, original_word)
            if shape:
                self.update_hanzi(word_feature)
        del self.seen

    def update_hanzi(self, feature):
        from .char_config import stroke_conf
        for i in range(len(feature)):
            if feature.is_cn[i]:
                han = feature.text[i]
                chai = feature.chaizi[i]
                stroke = feature.stroke[i]
                if stroke is None or chai is None:
                    continue
                for part in chai:
                    if part in stroke_conf:
                        if part not in self.hanzi_similar:
                            self.hanzi_similar[part] = set()
                        stk = stroke_conf[part]
                        self.hanzi_similar[part].add((han, (len(stk) + 0.0) / len(stroke)))


    def add_to_index(self, feature, level, py, sim_py, py_first, shape):
        if feature.text in self.seen:
            return
        self.seen.add(feature.text)
        next_nodes = [self.index]
        for i in range(len(feature)):
            new_next = set()
            for n in next_nodes:
                new_next.update(n.grow_char(i, feature, py, sim_py, py_first))
            next_nodes = new_next
        for n in next_nodes:
            n.match.append((feature.text, level))

    def match_at(self, start_pos, feature):
        current_nodes = set([(start_pos, (), self.index)])
        results = set()
        while len(current_nodes) > 0:
            nexts = set()
            for pos, trace, node in current_nodes:
                ms = node.match_char(pos, feature, trace, self.hanzi_similar)
                for m in ms:
                    if m[0] < len(feature):
                        nexts.add(m)
                    for mt in m[2].match:
                        results.add((m[0], m[1], mt))
            current_nodes = nexts
        return results

    def normalize_string(self, raw_text):
        raw_text = self.cc.convert(raw_text.lower())
        result_text = []
        position_mapping = []
        for i in range(len(raw_text)):
            ch = raw_text[i]
            if (ch >= u'\u4e00' and ch <= u'\u9fff') or \
               (ch >= '0' and ch <= '9') or (ch >= 'a' and ch <= 'z'):
                position_mapping.append(i)
                result_text.append(ch)
        return u"".join(result_text), position_mapping

    def get_segment_positions(self, sent):
        import jieba
        positions = []
        last_pos = 0
        for word in jieba.cut(sent, cut_all=False):
            new_pos = last_pos + len(word)
            positions.append((last_pos, new_pos))
            last_pos = new_pos
        return positions

    def is_chinese_char(self, ch):
        return ch >= u'\u4e00' and ch <= u'\u9fff'

    def is_noisy_alphanum(self, raw, beg, end):
        for i in range(beg, end + 1):
            if i >= len(raw):
                logger.error("Illegal query:[" + raw + ']')
                return False
            ch = raw[i]
            if self.is_chinese_char(ch):
                return False
        prev = None
        cur = beg - 1
        while cur > 0 and raw[cur].isspace():
            cur -= 1
        if cur >= 0 and not raw[cur].isspace():
            prev = raw[cur]

        nxt = None
        cur = end + 1
        if cur < len(raw) - 1 and raw[cur].isspace():
            cur += 1
        if cur < len(raw) and not raw[cur].isspace():
            nxt = raw[cur]

        if prev is None and nxt is None:
            return False
        if (prev is None or ord(prev) <= 127) and (nxt is None or ord(nxt) <= 127):
            return True
        return False


    def compute_match_score(self, raw_text, feature, results):
        import math
        ret = []
        ws = None
        for r in results:
            word = r[5][0]
            original_level = r[5][1]
            trace = r[4]
            fea, py, sim_py, py_first, shape, ws_filter, same_filter, alpha_filter, original_word = \
                self.name_feature[word]

            # 过滤一模一样的词
            exact = raw_text[r[0]:r[1]+1] == original_word
            if same_filter and exact:
                continue

            # 过滤处于更长英文数字串内部的字母串
            if alpha_filter and self.is_noisy_alphanum(raw_text, r[0], r[1]):
                continue

            if ws_filter:
                if ws is None:
                    ws = self.get_segment_positions(feature.text)
                start, end = r[2], r[3]
                filtered = False
                for p1, p2 in ws:
                    if (start < p1 and end > p1 and end < p2) or (start < p2 and end > p2 and start > p1):
                        filtered = True
                        break
                if filtered:
                    continue

            l = min(len(fea), len(trace)) # should be same
            score = 0
            remain = True
            fuzzy_types = set()

            for i in range(l):
                tr = trace[i]
                tp = tr[0]
                part = tr[1]
                original_ch = fea.text[i]
                original_py = fea.pinyin[i]

                if tp == 0:
                    if original_ch != part:
                        remain = False
                        break
                    score += 1.0
                    if exact:
                        fuzzy_types.add(u"完全一致")
                    else:
                        fuzzy_types.add(u"基本一致")
                elif tp == 1:
                    if not sim_py:
                        remain = False
                        break
                    fuzzy_types.add(u"近音汉字")
                    if part == fea.pinyin[i]:
                        score += 0.8
                    else:
                        score += 0.7
                elif tp == 2:
                    if not py_first: # 最后检查一轮是否满足匹配配置
                        remain = False
                        break
                    fuzzy_types.add(u"拼音首字母")
                    score += 0.5
                elif tp == 4:
                    if not shape:
                        remain = False
                        break
                    fuzzy_types.add(u"字形相似")
                    score += 0.6
                elif tp == 3:
                    if not py:
                        remain = False
                        break
                    fuzzy_types.add(u"汉字写成拼音")
                    if part == fea.pinyin[i]:
                        score += 0.8
                    else:
                        score += 0.7
            if remain:
                length_boost = (math.log(l+1) + 1.0) / 2
                score = round(100 * length_boost * score / (l + 1e-8)) / 100.0
                if u"基本一致" in fuzzy_types:
                    if len(fuzzy_types) > 1:
                        fuzzy_types.remove(u"基本一致")
                ret.append([r[0], r[1], (original_word, r[5][1]), score, list(fuzzy_types)])
        return ret

    def nms(self, results):
        results.sort(key=lambda x: (x[-2], x[1] - x[0], x[-3][1]), reverse=True)
        ret = []
        for r in results:
            good = True
            for current in ret:
                if r[1] < current[0] or r[0] > current[1]:
                    pass
                elif r[0] == current[0] and r[1] == current[1] and r[-1] == current[-1]:
                    pass
                else:
                    good = False
                    break
            if good:
                ret.append(r)
        return ret

    def match(self, raw_text):
        results = []
        text, position_mapping = self.normalize_string(raw_text)
        from .text_feature import TextFeature
        feature = TextFeature(text)
        for i in range(len(feature)):
            for end_pos, match_trace, match_word in self.match_at(i, feature):
                results.append([
                    position_mapping[i], position_mapping[end_pos - 1],
                    i, end_pos,
                    match_trace, match_word
            ])
        result_with_score = self.compute_match_score(raw_text, feature, results)
        match_result = self.nms(result_with_score)
        formatted = []
        for r in match_result:
            formatted.append({
                "start": r[0],
                "end": r[1],
                "pattern": r[2][0],
                "level": r[2][1],
                "score": r[3],
                "diagnosis": r[4]
            })
        return formatted

if __name__ == "__main__":
    import itrl.model.short_text.fuzzy_text.fuzzy_matcher as fuzzy_matcher
    matcher = fuzzy_matcher.FuzzyMatcher(["习近平`1`py`sim_py", "李克强`1`shape"])
    print(matcher.match("xijingping和李克虽"))