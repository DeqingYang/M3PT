#encoding=utf8

from functools import partial
from module.layers.NextVLAD import NeXtVLAD
from model.text.xbert import BertConfig, BertForMaskedLM
from transformers import BertTokenizer
from module.layers.biencoder import BiModalEncoder
from module.layers.channel_attention import SELayer

import torch
import torch.nn.functional as F
from torch import nn
import numpy as np
import random,math
from module.layers.cross_trans import build_transformer
from module.loss.pair_loss import get_triplet_loss, contrastive_loss

class AMSoftmax(nn.Module):
    def __init__(self, in_features, out_features):
        super(AMSoftmax, self).__init__()
        self.in_feature = in_features
        self.out_feature = out_features
        self.kernel = nn.Parameter(torch.zeros((in_features, out_features), requires_grad=True))
        nn.init.kaiming_uniform_(self.kernel)

    def forward(self, input_feature):
        # 每次运行前归一化一次
        with torch.no_grad():
            self.kernel.div_(torch.norm(self.kernel, p=2, dim=0, keepdim=True))
        # self.kernel = self.kernel / torch.norm(self.kernel, p=2, dim=0, keepdim=True)

        inner_product = input_feature @ self.kernel
        return inner_product

class ALBEF(nn.Module):
    @classmethod
    def from_pretrained(cls, config):
        weight_path = config['model_path']
        pretrained_model = torch.load(weight_path, map_location="cpu")
        # 不再使用初始化模型
        config['init_weights'] = False

        model = ALBEF.from_config(config)
        # checkpoint = {}
        # for key in pretrained_model["state_dict"]:
        #     if "imc_head" in key:
        #         continue
        #     checkpoint[key] = pretrained_model["state_dict"][key]

        model.load_state_dict(pretrained_model["state_dict"], strict=True)

        return model

    @classmethod # 类方法（不需要实例化类就可以被类本身调用）
    def from_config(cls, conf): # cls : 表示没用被实例化的类本身
        model = ALBEF(conf)
        return model

    def __init__(self, config):
        super().__init__()
        
        self.tokenizer = BertTokenizer.from_pretrained(config['bert_dic'])

        embed_dim = config['embed_dim']
        image_feature_dim = config['image_feature_dim']

        # 图像模型
        # self.it_encoder = BiModalEncoder(768, 768, None, 0.1, 6, 384, 384, 2)
        self.content_head = NeXtVLAD(dim=768, num_clusters=64, lamb=2, groups=16, frame_num=414)

        # 文本模型
        bert_config = BertConfig.from_json_file(config['bert_config'])
        if config['init_weights']:
            self.text_model = BertForMaskedLM.from_pretrained(config['bert_model'], config=bert_config)
        else:
            self.text_model = BertForMaskedLM(config=bert_config)

        # 表征向量长度
        text_feature_dim = self.text_model.config.hidden_size

        self.content_att = SELayer(6144)

        # 最后全链接层
        self.image_hidden_layer = nn.Linear(embed_dim, text_feature_dim)
        self.content_hidden_layer = AMSoftmax(6144, text_feature_dim)
        self.content_fc_layer = AMSoftmax(text_feature_dim, embed_dim)
        self.query_fc_layer = AMSoftmax(text_feature_dim, embed_dim)

        self.itm_head = nn.Linear(text_feature_dim, 2)

        # 温度系数
        self.temp = nn.Parameter(torch.ones([]) * config['temp'])
        self.criterion = nn.BCEWithLogitsLoss()
        # self.sigmoid = nn.Sigmoid()

    def get_tokenizer(self):
        return self.tokenizer


    def encode_text(self, text):
        text_output = self.text_model.bert(text["input_ids"], attention_mask = text["attention_mask"], return_dict = True, mode = 'text')
        text_embeds = text_output.last_hidden_state

        return text_embeds


    def encode_content(self, image_embeds, image_mask, texts):
        # 图片特征维度映射
        image_embeds = self.image_hidden_layer(image_embeds)

        # 图片特征，文本特征，图文交互特征，文图交互特征。文本特征还包括不同类型(描述,亮点,评论,类型等)的文本。
        text_embeds, text_mask = [], []
        for text in texts:
            text_output = self.text_model.bert(text["input_ids"], attention_mask = text["attention_mask"], return_dict = True, mode = 'text')
            text_embeds.append(text_output.last_hidden_state)
            # text_mask.append(text["attention_mask"])

        text_embeds = torch.cat(text_embeds, dim=1)
        # text_mask = torch.cat(text_mask, dim=1)

        # 图文交互特征
        # it_masks = {'text_mask':text_mask.unsqueeze(1), 'image_mask':image_mask.unsqueeze(1)}
        # it_embeds, ti_embeds = self.it_encoder((image_embeds, text_embeds), it_masks)

        # 内容表征, 特征融合
        content_embeds = torch.cat((image_embeds, text_embeds), dim=1) # 图文特征拼接
        content_embeds = self.content_head(content_embeds).unsqueeze(2)
        content_embeds = self.content_att(content_embeds).squeeze(2)
        content_feat = self.content_hidden_layer(content_embeds)

        return content_feat


    def it_match(self, image_embeds, text_embeds, text_atts):
        # image_embeds = image_embeds.unsqueeze(1)
        image_atts = torch.ones(image_embeds.size()[:-1],dtype=torch.long).to(image_embeds.device)
        output = self.text_model.bert(encoder_embeds = text_embeds, 
                                        attention_mask = text_atts,
                                        encoder_hidden_states = image_embeds,
                                        encoder_attention_mask = image_atts,
                                        return_dict = True,
                                        mode = 'fusion',
                                    )
        score = self.itm_head(output.last_hidden_state[:,0,:])
        score = torch.sigmoid(score)[:, 1]

        return score


    def calc_itm_loss(self, image_embeds, text_embeds, text, sims):
        sim_i2t, sim_t2i = sims, sims.t()
        image_embeds = image_embeds.unsqueeze(1)
        image_atts = torch.ones(image_embeds.size()[:-1],dtype=torch.long).to(image_embeds.device)
        output_pos = self.text_model.bert(encoder_embeds = text_embeds, 
                                        attention_mask = text["attention_mask"],
                                        encoder_hidden_states = image_embeds,
                                        encoder_attention_mask = image_atts,
                                        return_dict = True,
                                        mode = 'fusion',
                                    )
        with torch.no_grad():
            bs = image_embeds.size(0)
            weights_i2t = F.softmax(sim_i2t[:,:bs],dim=1)
            weights_t2i = F.softmax(sim_t2i[:,:bs],dim=1)
            weights_i2t.fill_diagonal_(0)
            weights_t2i.fill_diagonal_(0)
        # select a negative image for each text
        image_neg_idx = torch.multinomial(weights_t2i, 1) # 根据相似度大小取值，难分样本为相似度大的
        image_embeds_neg = image_embeds[image_neg_idx].squeeze(1)

        # select a negative text for each image
        text_neg_idx = torch.multinomial(weights_i2t, 1)
        text_embeds_neg = text_embeds[text_neg_idx].squeeze(1)
        text_atts_neg = text["attention_mask"][text_neg_idx].squeeze(1)

        text_embeds_all = torch.cat([text_embeds, text_embeds_neg],dim=0)
        text_atts_all = torch.cat([text["attention_mask"], text_atts_neg],dim=0)

        image_embeds_all = torch.cat([image_embeds_neg, image_embeds],dim=0)
        image_atts_all = torch.cat([image_atts, image_atts],dim=0)

        output_neg = self.text_model.bert(encoder_embeds = text_embeds_all,
                                        attention_mask = text_atts_all,
                                        encoder_hidden_states = image_embeds_all,
                                        encoder_attention_mask = image_atts_all,
                                        return_dict = True,
                                        mode = 'fusion',
                                    )

        vl_embeddings = torch.cat([output_pos.last_hidden_state[:,0,:], output_neg.last_hidden_state[:,0,:]],dim=0)
        vl_output = self.itm_head(vl_embeddings)
        itm_labels= torch.cat([torch.ones(bs,dtype=torch.long),torch.zeros(2*bs,dtype=torch.long)], dim=0).to(image_embeds.device)
        loss_itm = F.cross_entropy(vl_output, itm_labels)

        return loss_itm 


    def forward(self, image_embeds, image_mask, texts, query, tasks):
        with torch.no_grad():
            self.temp.clamp_(0.05, 0.3)

        content_embed = self.encode_content(image_embeds, image_mask, texts)
        content_feat = F.normalize(self.content_fc_layer(content_embed), p=2, dim=1)

        # 标签表征
        query_embeds = self.encode_text(query)
        query_feat = F.normalize(self.query_fc_layer(query_embeds[:,0,:]), p=2, dim=1)

        # 相关性
        sims = query_feat @ content_feat.t()

        # 对比损失，相关性分类
        loss = 0
        if "itc" in tasks:
            distance = torch.sqrt(2*(1-sims))
            try:
                loss += get_triplet_loss(distance, loss_weights=[1, 1], margin=0.1, bidirection=True)
            except:
                pass

            # print(self.temp)
            norm_sims = sims * 20

            labels = torch.arange(content_feat.shape[0], dtype=torch.long, device=content_feat.device)
            loss += (F.cross_entropy(norm_sims, labels) + F.cross_entropy(norm_sims.t(), labels)) / 2

        ##================= ITM ========================##
        if "itm" in tasks:
            loss += self.calc_itm_loss(content_embed, query_embeds, query, sims)

        return loss


def build_model(config):
    if 'model_path' in config:
        model = ALBEF.from_pretrained(config)
    else:
        model = ALBEF.from_config(config)

    return model
