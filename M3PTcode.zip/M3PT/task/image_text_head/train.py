import sys
sys.path.append("../..")

import argparse
import json
import torch
from torch.optim import AdamW
import torch.optim as optim
from tqdm import tqdm
from tensorboardX import SummaryWriter
import dataset
from model.image.align_q2l_fusion import build_model
import util.torch_util as utils
from module.scheduler import create_scheduler
from module.optim import create_optimizer
import logging
import os
import torch.distributed as dist
from util.yacs import load_config

logger = logging.getLogger(__name__)


def freeze_bone_layer(model):
    filter_list = ["layer.6", "layer.7", "layer.8", "layer.9", "layer.10", "layer.11","itm_head","imc_head","cls.predictions"]
    for name, param in model.named_parameters():
        flag = False
        for key in filter_list:
            if key in name:
                flag = True
                break
        if flag: continue
        param.requires_grad = False


def freeze_head_layer(model):
    filter_set = set(["layer.6", "layer.7", "layer.8", "layer.9", "layer.10", "layer.11", "itm_head", "imc_head"])

    for name, param in model.named_parameters():
        for key in filter_set:
            if key in name:
                param.requires_grad = False


class Trainer(object):
    def __init__(self, opt):
        self.opt = opt
        self.total_iter = 0

        # 定义summary
        self.writer = SummaryWriter(self.opt.train.save_dir)

        # 初始化训练数据
        self.train_loader = dataset.create_local_dataloader(self.opt.data)
        # self.val_loader = dataset.create_local_dataloader(self.opt.data, is_train=False)

        # 初始化模型
        model = build_model(self.opt.model)
        model = model.to(self.opt.device)
        if self.opt.gpu_count > 1:
            model = torch.nn.DataParallel(model, device_ids=self.opt.devices_ids, output_device=self.opt.device)
     
        # freeze_head_layer(model)
        # freeze_bone_layer(model)
        for name, param in model.named_parameters(): print(name, param.requires_grad)
        # 设置优化器和学习率
        optimizer = create_optimizer(self.opt.train.optimizer, model)
        self.scheduler, _ = create_scheduler(self.opt.train.schedular, optimizer)

        # 其他初始参数
        self.max_length = self.opt.data.get('max_text_length', 50)
        if self.opt.gpu_count > 1:
            self.tokenizer = model.module.get_tokenizer()
        else:
            self.tokenizer = model.get_tokenizer()

        self.model, self.optimizer = model, optimizer

        # 从断点处继续训练
        self.opt["start_epoch"] = 0
        if hasattr(self.opt.train, "resume"):
            if not os.path.isfile(self.opt.train.resume):
                raise RuntimeError("=> no checkpoint found at '{}'" .format(self.opt.resume))
            checkpoint = torch.load(self.opt.train.resume)
            self.opt['start_epoch'] = checkpoint['epoch']

            if self.opt.gpu_count > 1:
                self.model.module.load_state_dict(checkpoint['state_dict'])
            else:
                self.model.load_state_dict(checkpoint['state_dict'])

            self.optimizer.load_state_dict(checkpoint['optimizer'])

        if self.scheduler is not None and self.opt.start_epoch > 0:
            self.scheduler.step(start_epoch)


    def training(self, epoch):
        warmup_steps = self.opt.train.schedular.warmup_epochs
        step_size = 1000
        warmup_iterations = warmup_steps*step_size
        if epoch > 0:
            self.scheduler.step(epoch + warmup_steps)

        tbar = tqdm(self.train_loader)
        data_num = 5000000
        batch_loss, best_score = [], float("inf")
        self.model.train()
        for idx, item in enumerate(tbar):
            if not item or item["image"].shape[0] < 3:
                continue

            texts = []
            for text in item['text']:
                text = dict(self.tokenizer(text, padding='max_length', truncation=True, return_tensors='pt', max_length=self.max_length))
                texts.append(text)

            # import pdb; pdb.set_trace()
            target = dict(self.tokenizer(item["target"], padding='max_length', truncation=True, return_tensors='pt', max_length=self.max_length))
            texts = utils.move_to(texts, self.opt.device)
            target = utils.move_to(target, self.opt.device)
            image = item["image"].to(self.opt.device)
            image_mask = item["image_mask"].to(self.opt.device)
            self.optimizer.zero_grad()

            loss = self.model(image, image_mask, texts, target, self.opt.train.tasks)
            loss = loss.mean()

            loss.backward()
            self.optimizer.step()

            if (epoch == 0) and (idx % step_size == 0) and (idx <= warmup_iterations): 
                self.scheduler.step(idx // step_size)

            self.total_iter += 1
            loss_val = loss.item()
            
            if len(batch_loss) >= 100:
                batch_loss.pop(0)
            batch_loss.append(loss_val)
            q_num = len(batch_loss)

            mean_loss = sum(batch_loss)/q_num
            lr = self.optimizer.param_groups[0]['lr']
            self.writer.add_scalar('train/loss_iter', loss_val, self.total_iter)
            self.writer.add_scalar('train/mean_loss', mean_loss, self.total_iter)
            self.writer.add_scalar('learning_rate', lr, self.total_iter)

            tbar.set_description('%d: mloss: %.3f loss %.3f lr:%f' % (idx, mean_loss, loss_val, lr))

            if self.total_iter % 1000 == 0:
                # acc, rec, f1_score = self.validation()
                # self.model.train()
                # if (f1_score < best_score)) or (self.total_iter % 5000 == 0):
                if ((mean_loss >= 1e-8) and (mean_loss < best_score)) or (self.total_iter % 10000 == 0):
                    save_path = '{}_{}_{}.pth'.format(self.opt.train.checkpoint_prefix, self.total_iter, mean_loss)
                    utils.save_model_and_training_state(save_path, mean_loss, epoch+1, self.model)
                    best_score = mean_loss

        if utils.is_main_process():
            final_path = '{}_final_{}.pth'.format(self.opt.train.checkpoint_prefix, epoch+1)
            utils.save_model_and_training_state(final_path, best_score, epoch+1, self.model)


    def validation(self):
        '''一部分去重tag做为测试集，返回PRF'''
        self.model.eval()

        # 生成tag的embed
        # 只取这些tag的样本
        threshod = 0.5
        texts = []

        rec_dict = {key:[0, 0, 0] for key in texts}

        tag_list = np.array(texts)
        text_feature = self.tokenizer(texts, padding=True, truncation=True, return_tensors='pt', max_length=50)
        text = text_feature.to(opt.device)
        with torch.no_grad():
            text_atts = text["attention_mask"]
            text_feats = model.encode_text(text)
            text_embeds = F.normalize(model.text_hidden_layer(text_feats[:,0,:]))

        text_embeds = text_embeds.cpu().detach().numpy()
        batch_num = text_embeds.shape[0]

        tbar = tqdm(self.val_loader)
        for i, item in enumerate(tbar):
            image = item["image"].unsqueeze(0).to(opt.device)
            label = item["text"]

            if label not in texts:
                continue

            with torch.no_grad():
                image_feat = model.encode_image(image)
                image_embed = model.image_hidden_layer(image_feat[:,0,:])
                image_embed = F.normalize(image_embed, p=2, dim=1)

            # 重复N次
            image_embed = image_embed.cpu().detach().numpy()
            # 计算相似度获取标签
            image_embeds = np.repeat(image_embed, batch_num, axis=0)
            sim_i2t = np.dot(image_embeds, text_embeds.T)[0]

            topk_idx = sim_i2t.argsort()[::-1][:10]
            topk_tag = tag_list[topk_idx]
            topk_score = sim_i2t[topk_idx]

            # 消歧模型
            image_feats = image_feat.repeat(topk_idx.shape[0], 1, 1)
            scores = model.it_match(image_feats, text_feats[topk_idx.copy()], text_atts[topk_idx.copy()]) 
            scores = scores.cpu().detach().numpy()
            tag_idx = scores > threshod
        
            pred_score = list(topk_score[tag_idx])
            pred_tag = list(topk_tag[tag_idx])
            
            tags = []
            for tag, score in zip(pred_tag, pred_score):
                if score >= threshod and tag in texts:
                    tags.append(tag)

            tags = set(tags)
            if label in rec_dict:
                rec_dict[label][0] += 1.0

            for key in tags:
                rec_dict[key][1] += 1.0
                if key == label:
                    rec_dict[key][2] += 1.0

        p_sum, r_sum, f_sum = 0, 0, 0
        for key, val in rec_dict.items():
            p = val[2]/max(val[1],1)
            r = val[2]/max(val[0],1)
            f1 = (2 * p * r)/ max(p+r, 1)

            p_sum += p
            r_sum += r
            f_sum += f1

        count = len(rec_dict)
        acc, rec, f1_score = p_sum/count, r_sum/count, f_sum/count

        return acc, rec, f1_score


def main():
    print(torch.__version__)
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--config_path', type=str, default="./config_vit.yml")
    parser.add_argument('-s', '--seed', type=int, default=1024)

    args = parser.parse_args()

    opt = load_config(args.config_path)

    # import pdb; pdb.set_trace()
    opt['devices_ids'] = [0,1,2,3]
    opt['device'] = opt['devices_ids'][0]
    opt['gpu_count'] = len(opt['devices_ids'])

    logger = logging.getLogger().setLevel(logging.INFO)
    utils.fix_random_seed(args.seed)

    print("cuda is available : ", torch.cuda.is_available(), flush=True)

    trainer = Trainer(opt)
    print('Starting Epoch:', trainer.opt.start_epoch)
    print('Total Epoches:', trainer.opt.train.epochs)
    for epoch in range(trainer.opt.start_epoch, trainer.opt.train.epochs):
        trainer.training(epoch)

    trainer.writer.close()
 
if __name__ == '__main__':
    main()
