from odps import ODPS
odps_obj = ODPS(access_id, access_key, project, endpoint='http://service-corp.odps.aliyun-inc.com/api')

# https://pyodps.readthedocs.io/zh_CN/latest/
class ODPSIterator(object):
    def __init__(self, odps_obj, table_name, partition_spec=None,
                 read_once=False, record_parser=None, worker_id=None, num_workers=None, retry=True):
        self.o = odps_obj
        self.table_name = table_name
        self.partition_spec = partition_spec
        self.retry = retry

        if partition_spec is not None:
            self.partition_name = partition_spec.split("=")[0]
        else:
            self.partition_name = None

        self.read_once = read_once
        if record_parser is None:
            # 默认 parser
            self.record_parser = lambda record, partition: dict([kv for kv in record if kv[1] is not None])
        else:
            self.record_parser = record_parser
        self.worker_id = worker_id
        self.num_workers = num_workers
        # 最近一次读取位置，用于失败重试，失败后重新调用 __call__ 可以重上次挂掉的地方重新开始
        self.last_index = None
        from odps import options
        options.tunnel.use_instance_tunnel = True
        options.tunnel.limit_instance_tunnel = False

    def set_worker(self, worker_id, num_workers):
        self.worker_id = worker_id
        self.num_workers = num_workers

    def __call__(self):
        while True:
            try:
                table = self.o.get_table(self.table_name)
                with table.open_reader(partition=self.partition_spec, compress_algo='snappy') as reader:
                    total = reader.count
                    start = 0
                    end = total
                    if total == 0:
                        return
                    if self.worker_id is not None and self.num_workers is not None:
                        per_worker = int(total / self.num_workers)
                        if self.worker_id + 1 != self.num_workers:
                            start = self.worker_id * per_worker
                            end = start + per_worker
                        else:
                            start = self.worker_id * per_worker
                            end = total
                    if end == start:
                        return
                    logger.info("worker:{}/{}, partition:{}, range: {}-{}".format(self.worker_id, self.num_workers, self.partition_spec, start, end))
                    if self.last_index is not None:
                        logger.warn("Worker {} start from offset:({})".format(self.worker_id, self.last_index))
                        start = self.last_index
                    self.last_index = start
                    for record in reader[start:end]:
                        # record parser 里可以获取当前 partition
                        data = self.record_parser(record, self.partition_name)
                        if data is not None:
                            yield data
                        self.last_index += 1
                    # 读完一次，读取进度重置
                    self.last_index = None
                    if self.read_once:
                        break
            except:
                if self.retry:
                    traceback.print_exc()
                    logger.error("ODPS reader failed, restarting...")
                else:
                    raise
