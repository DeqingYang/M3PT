import sys
sys.path.append("../..")

import data.preprocess.image_augument as image_augument
import data.preprocess.image as image_preprocess
import cv2
import random
import numpy as np
from torchvision import transforms
from PIL import Image
from torchvision.transforms import InterpolationMode
import re,os
import util.torch_util as utils
import torch
from torch.utils.data import Dataset, DataLoader
from multiprocessing.dummy import Pool as ThreadPool

class TrainReaderBatch(object):
    def __init__(self, data_path, batch_size, image_size, transform):
        self.transform = transform
        self.batch_size = batch_size
        self.image_size = image_size
        self.num_class = 411
        self.tag_list = tag_list
        self.tag_index = tag_index
        # 转换为关系矩阵，TODO稀疏矩阵
        tag_tree_dict = {}
        for item in tag_tree:
            num = len(item)
            if num <= 1:
                continue
            for i in range(1,num):
                key = item[i]
                if key in tag_tree_dict:
                    tag_tree_dict[key] = tag_tree_dict[key] | set(item[:i+1])
                else:
                    tag_tree_dict[key] = set(item[:i+1])
        
        diag = [1] * self.num_class
        relation = np.diag(diag)
        for key, item in tag_tree_dict.items():
            if key not in self.tag_index:
                continue

            row = self.tag_index[key]
            for val in item:
                if val in self.tag_index:
                    col = self.tag_index[val]
                    relation[row, col] = 1
        self.relation = torch.Tensor(relation)

        # 读取数据
        self.data = {}
        with open(data_path) as fin:
            for line in fin:
                # image_id, image_str, label, target, quality_score, aesthetic_score = line.strip().split("<sep>")
                image_str, tag, label = line.strip().split("<sep>")
                label = int(label)
                if tag in self.data:
                    self.data[tag].append((image_str, label))
                else:
                    self.data[tag] = [(image_str, label)]

    def parse_item(self, tag):
        items = random.sample(self.data[tag], 15)
        tag_list, image_list, label_list = [], [], []
        for image_path, label in items:
            image = image_preprocess.read_image(image_path)
            try:
                image = self.transform(image)
            except:
                image = torch.zeros([3, self.image_size, self.image_size], dtype=torch.float)
            
            tag_list.append(tag)
            image_list.append(image)
            label_list.append(label)

        return tag_list, image_list, label_list

    def __call__(self):
        # 1. 采样key: 冲突的随机保留一项, 返回
        # ，然后sample batch_size个组合返回
        # 如果并行生成
        pool = ThreadPool(32)
        while True:
            if len(self.tag_list) < self.batch_size:
                global_size = len(self.tag_list)
            else:
                global_size = self.batch_size
            
            global_cand_list = np.random.choice(self.tag_list, size=global_size, replace=False, p=None)
            random.shuffle(global_cand_list)
            cand_list = []
            for val in global_cand_list:
                if type(val) == list:
                    cand_list += val
                else:
                    cand_list.append(val)

                if len(cand_list) > self.batch_size:
                    cand_list = random.sample(cand_list, self.batch_size)
                    break

            # cand_list = list(set(cand_list)) # 去重
            # 获取上下位关系
            # cand_index = [self.tag_index[label] for label in cand_list]          
            # relation = self.tag_tree[np.ix_(cand_index, cand_index)]

            image_batch, text_batch, label_batch = [], [], []
            res = pool.map(self.parse_item, cand_list)
            for item in res:
                text_batch += item[0]
                image_batch += item[1]
                label_batch += item[2]
                
            image_batch = torch.Tensor(np.stack(image_batch))
            label_batch = torch.Tensor(label_batch).long()
            label_batch = self.relation[label_batch]
            # label_batch = torch.nn.functional.one_hot(label_batch, num_classes=self.num_class).double()
            batch_data = {"image":image_batch, "text":text_batch, "target":label_batch, "relation":self.relation}

            yield batch_data


class TrainReader(object):
    def __init__(self, data_path, batch_size):
        self.batch_size = batch_size
        self.tag2poi = np.load(data_path+'tag2poi.npy', allow_pickle=True).item()
        self.poi2tag = np.load(data_path+'poi2tag.npy', allow_pickle=True).item()
        self.text_feat = np.load(data_path+'text_feat.npy', allow_pickle=True).item()
        self.image_feat = np.load(data_path+'image_feat.npy', allow_pickle=True).item()
        self.label_list = list(self.tag2poi.keys())
        self.text_names = ['poi_name', 'first_category', 'second_category', 'third_category', 'title', 'characteristic', 'description']


    def __call__(self):
        while True:
            if len(self.label_list) < self.batch_size:
                batch_size = len(self.label_list)
            else:
                batch_size = self.batch_size
            
            # 采样权重回传, 如果预测类目错误较多则提高其采样权重
            cand_list = random.sample(self.label_list, batch_size)
            image_batch, mask_batch, text_batch = [], [], [[] for i in range(len(self.text_names))]
            visited, final_tag = set(), []
            for label in cand_list:
                if len(final_tag) >= 128:
                    break
                poi_id = random.sample(self.tag2poi[label], 1)[0]
                temp = set()
                tags = self.poi2tag.get(poi_id, set())
                if label in visited: continue
                visited |= tags

                final_tag.append(label)
                image_feat = self.image_feat.get(poi_id, np.array([]))
                frame_num = image_feat.shape[0]
                pad_num = 64 - frame_num
                fill_array = np.zeros((pad_num, 512))
                if frame_num > 0:
                    image_feat = np.concatenate((image_feat, fill_array), axis=0)
                else:
                    image_feat = fill_array
                # image_feat = np.pad(image_feat, ((pad_num,0), (0,0)), 'edge')
                image_mask = [1] * frame_num + ([0] * pad_num)
                mask_batch.append(image_mask)

                text_feat = self.text_feat[poi_id]
                for i, key in enumerate(self.text_names):
                    text_batch[i].append(text_feat.get(key, ""))
                image_batch.append(image_feat)

            image_batch = torch.Tensor(image_batch)
            mask_batch = torch.Tensor(mask_batch)

            batch_data = {"image":image_batch, "image_mask":mask_batch, "text":text_batch, "target":final_tag}

            yield batch_data


class TestReader(object):
    def __init__(self, data_path):
        self.poi2tag = np.load(data_path+'poi2tag_test.npy', allow_pickle=True).item()
        self.text_feat = np.load(data_path+'text_feat.npy', allow_pickle=True).item()
        self.image_feat = np.load(data_path+'image_feat.npy', allow_pickle=True).item()
        self.text_names = ['poi_name', 'first_category', 'second_category', 'third_category', 'title', 'characteristic', 'description']


    def __len__(self):
        return len(self.data)

    def __call__(self):
        for poi_id in self.poi2tag:
            image_batch, mask_batch, text_batch = [], [], [[] for i in range(len(self.text_names))]
            image_feat = self.image_feat.get(poi_id, np.array([]))
            frame_num = image_feat.shape[0]
            pad_num = 64 - frame_num
            fill_array = np.zeros((pad_num, 512))
            if frame_num > 0:
                image_feat = np.concatenate((image_feat, fill_array), axis=0)
            else:
                image_feat = fill_array
        
            # image_feat = np.pad(image_feat, ((pad_num,0), (0,0)), 'edge')
            image_mask = [1] * frame_num + ([0] * pad_num)
            mask_batch.append(image_mask)

            text_feat = self.text_feat[poi_id]
            for i, key in enumerate(self.text_names):
                text_batch[i].append(text_feat.get(key, ""))
            image_batch.append(image_feat)

            final_tag = list(self.poi2tag[poi_id])
            image_batch = torch.Tensor(image_batch)
            mask_batch = torch.Tensor(mask_batch)

            batch_data = {"poi_id":poi_id, "image":image_batch, "image_mask":mask_batch, "text":text_batch, "target":final_tag}

            yield batch_data


def create_dataset(config, is_train):
    if is_train:
        loader = TrainReader(config['train_path'], config['batch_size'])()
    else:
        loader = TestReader(config['test_path'])()
        # dataset = EvalReader(config['test_file'], test_transform, config['image_size'])
        # loader = DataLoader(dataset, batch_size=config['batch_size'], num_workers=config['num_workers'], pin_memory=True, shuffle=False, drop_last=False)    
    
    return loader


def create_local_dataloader(config, is_train=True):
    dataset = TrainReader(config['train_path'], config['batch_size'])()

    return dataset


if __name__ == "__main__":
    conf = {
        "train_path": "/ProjectRoot/dataset/text_image/fliggy_tag/",
        "test_path": "/ProjectRoot/dataset/poi_pair_data/test_data.txt",
        "batch_size": 100,
        "num_workers": 5,
    }
    dl = create_local_dataloader(conf)
    from tqdm import tqdm
    for batch in tqdm(dl):
        import pdb; pdb.set_trace()
        pass
