import sys
sys.path.append("../..")

import argparse
import json
import torch
from tqdm import tqdm
import dataset
from model.image.align_q2l_fusion import build_model
import util.torch_util as utils
import logging
import os
import numpy as np
from util.yacs import load_config
import torch.nn.functional as F


def validation(opt):
    # 初始化训练数据
    val_loader = dataset.create_dataset(opt.data, is_train=False)

    # 初始化模型
    model = build_model(opt.model)
    model = model.to(opt.device)
    model.eval()

    # 分词器
    tokenize = model.get_tokenizer()

    # 生成tag的embed
    texts = ["主题乐园","水族馆","海豚","企鹅","动物","露营","夜游","国家公园","国家地质公园","国家森林公园"]
    tag_list = np.array(texts)
    text_feature = tokenize(texts, padding=True, truncation=True, return_tensors='pt', max_length=50)
    text = text_feature.to(opt.device)
    with torch.no_grad():
        text_atts = text["attention_mask"]
        text_feats = model.encode_text(text)
        text_embeds = F.normalize(model.query_fc_layer(text_feats[:,0,:]))

    text_embeds = text_embeds.cpu().detach().numpy()
    batch_num = text_embeds.shape[0]
    # tbar = tqdm(val_loader)
    count = 0
    # label_num, pred_num, acc_num
    rec_dict = {key:[0, 0, 0] for key in texts}
    # outsim = open(f"{DATA_PATH}/online/vit_fv2_sim.txt", "w")
    output = open(f"./result.txt", "w")
    for i, item in enumerate(val_loader):
        texts = []
        for text in item['text']:
            text = dict(tokenize(text, padding='max_length', truncation=True, return_tensors='pt', max_length=50))
            texts.append(text)
        texts = utils.move_to(texts, opt.device)
        image = item["image"].to(opt.device)
        image_mask = item["image_mask"].to(opt.device)

        with torch.no_grad():
            image_feat = model.encode_content(image, image_mask, texts)
            image_embed = F.normalize(model.content_fc_layer(image_feat), p=2, dim=1)

        # 重复N次
        # image_embeds = image_embed.repeat(batch_num, 1, 1)
        image_embed = image_embed.cpu().detach().numpy()
        # 计算相似度获取标签
        image_embeds = np.repeat(image_embed, batch_num, axis=0)
        sim_i2t = np.dot(image_embeds, text_embeds.T)[0]

        topk_idx = sim_i2t.argsort()[::-1][:10]
        topk_tag = tag_list[topk_idx]
        topk_score = sim_i2t[topk_idx]

        sim_tag_str = ",".join(list(topk_tag))
        sim_score_str = ",".join([str(val) for val in topk_score])

        # import pdb; pdb.set_trace()
        # 消歧模型
        image_feats = image_feat.repeat(topk_idx.shape[0], 1, 1)
        scores = model.it_match(image_feats, text_feats[topk_idx.copy()], text_atts[topk_idx.copy()]) 
        scores = scores.cpu().detach().numpy()
        tag_idx = scores > 0.5
    
        pred_score = list(topk_score[tag_idx])
        pred_tag = list(topk_tag[tag_idx])

        pred_score_str = ",".join([str(val) for val in pred_score])
        pred_tag_str = ",".join(list(pred_tag))

        poi_id = item['poi_id']
        label = ",".join(item['target'])
        print(poi_id, label, "||", pred_tag_str, ":", pred_score_str)
        output.write("%s|%s|%s|%s|%s|%s\n"%(poi_id, label, pred_tag_str, pred_score_str, sim_tag_str, sim_score_str))
        if i%1000 == 0: output.flush()
    output.close()


def main():
    print(torch.__version__)
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--config_path', type=str, default="./config_vit.yml")
    parser.add_argument('-s', '--seed', type=int, default=1024)

    args = parser.parse_args()

    opt = load_config(args.config_path)

    # import pdb; pdb.set_trace()
    opt['devices_ids'] = [0]
    opt['device'] = opt['devices_ids'][0]
    opt['gpu_count'] = len(opt['devices_ids'])

    logger = logging.getLogger().setLevel(logging.INFO)
    utils.fix_random_seed(args.seed)

    print("cuda is available : ", torch.cuda.is_available(), flush=True)

    validation(opt)

 
if __name__ == '__main__':
    main()
