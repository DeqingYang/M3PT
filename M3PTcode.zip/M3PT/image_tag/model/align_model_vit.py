#encoding=utf8

from functools import partial
from model.vision_transformer import VisionTransformer
from model.xbert import BertConfig, BertForMaskedLM
from transformers import BertTokenizer
from typing import Optional

import torch
import torch.nn.functional as F
from torch import nn, Tensor
import numpy as np
import random,math
from torch.nn.modules.transformer import _get_activation_fn


class TransformerDecoderLayerOptimal(nn.Module):
    def __init__(self, d_model, nhead=8, dim_feedforward=2048, dropout=0.1, activation="relu",
                 layer_norm_eps=1e-5) -> None:
        super(TransformerDecoderLayerOptimal, self).__init__()
        self.norm1 = nn.LayerNorm(d_model, eps=layer_norm_eps)
        self.dropout = nn.Dropout(dropout)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.dropout3 = nn.Dropout(dropout)

        self.multihead_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout)

        # Implementation of Feedforward model
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.linear2 = nn.Linear(dim_feedforward, d_model)

        self.norm2 = nn.LayerNorm(d_model, eps=layer_norm_eps)
        self.norm3 = nn.LayerNorm(d_model, eps=layer_norm_eps)

        self.activation = _get_activation_fn(activation)

    def __setstate__(self, state):
        if 'activation' not in state:
            state['activation'] = torch.nn.functional.relu
        super(TransformerDecoderLayerOptimal, self).__setstate__(state)

    def forward(self, tgt: Tensor, memory: Tensor, tgt_mask: Optional[Tensor] = None,
                memory_mask: Optional[Tensor] = None,
                tgt_key_padding_mask: Optional[Tensor] = None,
                memory_key_padding_mask: Optional[Tensor] = None) -> Tensor:
        tgt = tgt + self.dropout1(tgt)
        tgt = self.norm1(tgt)
        tgt2 = self.multihead_attn(tgt, memory, memory)[0]
        tgt = tgt + self.dropout2(tgt2)
        tgt = self.norm2(tgt)
        tgt2 = self.linear2(self.dropout(self.activation(self.linear1(tgt))))
        tgt = tgt + self.dropout3(tgt2)
        tgt = self.norm3(tgt)
        return tgt


@torch.jit.script
class GroupFC(object):
    def __init__(self, embed_len_decoder: int):
        self.embed_len_decoder = embed_len_decoder

    def __call__(self, h: torch.Tensor, duplicate_pooling: torch.Tensor, out_extrap: torch.Tensor):
        for i in range(h.shape[1]):
            h_i = h[:, i, :]
            if len(duplicate_pooling.shape)==3:
                w_i = duplicate_pooling[i, :, :]
            else:
                w_i = duplicate_pooling
            out_extrap[:, i, :] = torch.matmul(h_i, w_i)


class MLDecoder(nn.Module):
    def __init__(self, num_classes, num_of_groups=-1, decoder_embedding=768,
                 initial_num_features=2048):
        super(MLDecoder, self).__init__()
        embed_len_decoder = 100 if num_of_groups < 0 else num_of_groups
        if embed_len_decoder > num_classes:
            embed_len_decoder = num_classes

        # switching to 768 initial embeddings
        decoder_embedding = 768 if decoder_embedding < 0 else decoder_embedding
        embed_standart = nn.Linear(initial_num_features, decoder_embedding)

        # non-learnable queries
        query_embed = nn.Embedding(embed_len_decoder, decoder_embedding)
        query_embed.requires_grad_(False)

        # decoder
        layer_decode = TransformerDecoderLayerOptimal(d_model=decoder_embedding, dim_feedforward=2048, dropout=0.1)
        self.decoder = nn.TransformerDecoder(layer_decode, num_layers=6)
        self.decoder.embed_standart = embed_standart
        self.decoder.query_embed = query_embed

        # group fully-connected
        self.decoder.num_classes = num_classes
        self.decoder.duplicate_factor = int(num_classes / embed_len_decoder + 0.999)
        self.decoder.duplicate_pooling = torch.nn.Parameter(torch.Tensor(embed_len_decoder, decoder_embedding, self.decoder.duplicate_factor))
        self.decoder.duplicate_pooling_bias = torch.nn.Parameter(torch.Tensor(num_classes))

        torch.nn.init.xavier_normal_(self.decoder.duplicate_pooling)
        torch.nn.init.constant_(self.decoder.duplicate_pooling_bias, 0)
        self.decoder.group_fc = GroupFC(embed_len_decoder)
        self.train_wordvecs = None
        self.test_wordvecs = None


    def forward(self, x):
        if len(x.shape) == 4:  # [bs,2048, 7,7]
            embedding_spatial = x.flatten(2).transpose(1, 2)
        else:  # [bs, 197, 468]
            embedding_spatial = x

        # [16, 49, 2048]
        # import pdb; pdb.set_trace()
        # 全链接特征映射, [16, 49, 768]
        embedding_spatial_786 = self.decoder.embed_standart(embedding_spatial)
        embedding_spatial_786 = torch.nn.functional.relu(embedding_spatial_786, inplace=True)

        bs = embedding_spatial_786.shape[0]
        query_embed = self.decoder.query_embed.weight # [20, 768]

        tgt = query_embed.unsqueeze(1).expand(-1, bs, -1)  # [20, 16, 768]
        h = self.decoder(tgt, embedding_spatial_786.transpose(0, 1))  # [embed_len_decoder, batch, 768]
        h = h.transpose(0, 1) # [16, 20, 768]

        # [16, 20, 23]
        out_extrap = torch.zeros(h.shape[0], h.shape[1], self.decoder.duplicate_factor, device=h.device, dtype=h.dtype)
        self.decoder.group_fc(h, self.decoder.duplicate_pooling, out_extrap)
        h_out = out_extrap.flatten(1)[:, :self.decoder.num_classes]

        h_out += self.decoder.duplicate_pooling_bias
        logits = h_out

        return logits


class AMSoftmax(nn.Module):
    def __init__(self, in_features, out_features):
        super(AMSoftmax, self).__init__()
        self.in_feature = in_features
        self.out_feature = out_features
        self.kernel = nn.Parameter(torch.zeros((in_features, out_features), requires_grad=True))
        nn.init.kaiming_uniform_(self.kernel)

    def forward(self, input_feature):
        # 每次运行前归一化一次
        with torch.no_grad():
            self.kernel.div_(torch.norm(self.kernel, p=2, dim=0, keepdim=True))

        inner_product = input_feature @ self.kernel
        return inner_product

class ALBEF(nn.Module):
    @classmethod
    def from_pretrained(cls, config):
        weight_path = config['model_path']
        pretrained_model = torch.load(weight_path, map_location="cpu")
        # 不再使用初始化模型
        config['init_weights'] = False

        model = ALBEF.from_config(config)
        model.load_state_dict(pretrained_model["state_dict"], strict=True)

        return model

    @classmethod # 类方法（不需要实例化类就可以被类本身调用）
    def from_config(cls, conf): # cls : 表示没用被实例化的类本身
        model = ALBEF(conf)
        return model

    def __init__(self, config):
        super().__init__()
        
        self.tokenizer = BertTokenizer.from_pretrained(config['bert_dic'])

        embed_dim = config['embed_dim']
        num_class = config['num_class']
        image_feature_dim = config['image_feature_dim']

        # 图像模型
        self.image_model = VisionTransformer(
            img_size=config['image_size'], patch_size=16, embed_dim=image_feature_dim, depth=12, num_heads=12,
            mlp_ratio=4, qkv_bias=True, norm_layer=partial(nn.LayerNorm, eps=1e-6))  

        # 文本模型
        bert_config = BertConfig.from_json_file(config['bert_config'])
        self.text_model = BertForMaskedLM(config=bert_config)

        # 表征向量长度
        text_feature_dim = self.text_model.config.hidden_size

        # 最后全链接层
        self.image_hidden_layer = AMSoftmax(image_feature_dim, embed_dim)
        self.text_hidden_layer = AMSoftmax(text_feature_dim, embed_dim)
        self.imc_head = MLDecoder(num_classes=num_class, initial_num_features=768, num_of_groups=100, decoder_embedding=embed_dim)
        self.itm_head = nn.Linear(text_feature_dim, 2)

    def get_tokenizer(self):
        return self.tokenizer

    def encode_image(self, image):
        image_embeds = self.image_model(image)
        return image_embeds

    def encode_text(self, text):
        text_output = self.text_model.bert(text["input_ids"], attention_mask = text["attention_mask"], return_dict = True, mode = 'text')
        text_embeds = text_output.last_hidden_state
        return text_embeds

    def it_match(self, image_embeds, text_embeds, text_atts):
        image_atts = torch.ones(image_embeds.size()[:-1],dtype=torch.long).to(image_embeds.device)
        output = self.text_model.bert(encoder_embeds = text_embeds, 
                                        attention_mask = text_atts,
                                        encoder_hidden_states = image_embeds,
                                        encoder_attention_mask = image_atts,
                                        return_dict = True,
                                        mode = 'fusion',
                                    )
        score = self.itm_head(output.last_hidden_state[:,0,:])
        score = torch.sigmoid(score)[:, 1]

        return score


    def image_class(self, image_embeds):
        logits = self.imc_head(image_embeds)

        return logits


    def forward(self, image):
        image_embeds = self.image_model(image)
        logits = self.imc_head(image_embeds)

        return logits

    def interpolate_pos_embed(self, pos_embed_checkpoint):
        # interpolate position embedding
        embedding_size = pos_embed_checkpoint.shape[-1]
        num_patches = self.image_model.patch_embed.num_patches
        num_extra_tokens = self.image_model.pos_embed.shape[-2] - num_patches
        # height (== width) for the checkpoint position embedding
        orig_size = int((pos_embed_checkpoint.shape[-2] - num_extra_tokens) ** 0.5)
        # height (== width) for the new position embedding
        new_size = int(num_patches ** 0.5)

        if orig_size != new_size:
            # class_token and dist_token are kept unchanged
            extra_tokens = pos_embed_checkpoint[:, :num_extra_tokens]
            # only the position tokens are interpolated
            pos_tokens = pos_embed_checkpoint[:, num_extra_tokens:]
            pos_tokens = pos_tokens.reshape(-1, orig_size, orig_size, embedding_size).permute(0, 3, 1, 2)
            pos_tokens = torch.nn.functional.interpolate(
                pos_tokens, size=(new_size, new_size), mode='bicubic', align_corners=False)
            pos_tokens = pos_tokens.permute(0, 2, 3, 1).flatten(1, 2)
            new_pos_embed = torch.cat((extra_tokens, pos_tokens), dim=1)
            print('reshape position embedding from %d to %d'%(orig_size ** 2,new_size ** 2))

            return new_pos_embed
        else:
            return pos_embed_checkpoint


def build_model(config):
    model = ALBEF.from_pretrained(config)

    return model

