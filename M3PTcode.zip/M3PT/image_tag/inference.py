# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved
import argparse
import glob
import hashlib
import multiprocessing as mp
import os, gc
import time
import cv2, json
import sys, traceback, oss2
import numpy as np
import requests
import tqdm, common_io
from io import BytesIO
import requests
import torch
import torch.nn.functional as F
from model.align_model_vit import build_model
from concurrent.futures import ThreadPoolExecutor, as_completed
from torchvision import transforms
from PIL import Image
from torchvision.transforms import InterpolationMode



def download_weights(oss_path, local_path):
    print('oss_path=', oss_path)
    bucket.get_object_to_file(oss_path, local_path)

def get_parser():
    parser = argparse.ArgumentParser(description="model for builtin models")
    parser.add_argument("--tables", default="", type=str, help="odps input table names")
    parser.add_argument("--outputs", default="", type=str, help="odps outout table names")
    parser.add_argument("--model_path", default="gavin.hgz/plugin/poi_tag_predict.pth", type=str,
                        help="output tables")
    parser.add_argument("--limit", default=-1, type=int, help="label index")
    parser.add_argument("--sthred", default=0.6, type=float, help="label sim score")
    parser.add_argument("--dthred", default=0.6, type=float, help="label distinct score")
    parser.add_argument("--scale", default=1.0, type=float, help="image resize scale")
    parser.add_argument("--tags", default="温泉,滑雪,电竞房,影音房", type=str, help="tags")
    parser.add_argument("--batch_size", default=32, type=int, help="label index")
    parser.add_argument("--selected_cols", default="image_url", type=str, help="output tables")
    return parser


def data_generator(input_table, batch_size):
    # domestic 是否为国内,0为国际，1为国内，2为全量
    reader = common_io.table.TableReader(input_table, slice_count=int(os.environ.get("WORLD_SIZE")),
                                         slice_id=int(os.environ.get("RANK")),
                                         selected_cols=args.selected_cols)
    while True:
        try:
            records = reader.read(batch_size, allow_smaller_final_batch=True)
            # records = reader.read(5000)
            yield records
        except GeneratorExit:
            raise StopIteration()
        except common_io.exception.OutOfRangeException:
            raise StopIteration()
        except:
            raise RuntimeError("odps_reader error")


def get_time():
    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))


def percentage(v):
    return "%.2f%%" % (v * 100)


headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'}
import base64 as b64
def get_img_from_alicdn_url(url):
    resp = requests.get(url=url, timeout=(3.05, 5), headers=headers)
    if resp.status_code != 200:
        print(url, "resp.code != 200", 'resp.status_code=', resp.status_code)
        data = None
    else:
        data = resp.content
        if data is None or len(data) == 0:
            retry_count = 3
            while retry_count > 0:
                retry_count -= 1
                try:
                    resp = requests.get(url=url, timeout=5)
                    data = resp.content
                    if data is not None and len(data) != 0:
                        break
                except Exception as e:
                    time.sleep(0.5)
                    print(">>> Temp Download fail: retry_count left:{}".format(retry_count), e)
            print(">>> Download fail: image {} failed to retry read.!".format(url))
    if data is None:
        return None

    # base64 = b64.b64encode(data)
    pil_img = Image.open(BytesIO(data)).convert('RGB')

    return pil_img


def image_trans(height, width, image_size):
    data_trans = transforms.Compose([
            transforms.CenterCrop((height, width)),
            transforms.Resize((image_size, image_size), interpolation=InterpolationMode.BICUBIC),
            transforms.ToTensor(),
            transforms.Normalize((0.48145466, 0.4578275, 0.40821073), (0.26862954, 0.26130258, 0.27577711))
        ])

    return data_trans


# 将图片居中按比例裁切
def center_crop(image, scale):
    width, height = image.size
    resize_width, resize_height = width, height

    if scale <= 0:
        return resize_width, resize_height

    if (height / width) < scale:
        resize_width = int(height / scale)
    else:
        resize_height = int(scale * width)

    return resize_height, resize_width


def download_alicdn_url(row):
    url = row[0]
    if isinstance(url, bytes):
        url = url.decode('utf-8').strip()

    try:
        img = get_img_from_alicdn_url(url)
    except Exception as e:
        print(e, url)
        return url, None
    if img is None:
        return url, None

    # img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

    resize_height, resize_width = center_crop(img, scale)
    img = image_trans(resize_height, resize_width, image_size)(img)
    img = img.unsqueeze(0)

    return url, img


def get_MD5(s):
    if isinstance(s, str):
        return hashlib.md5(s.encode('utf-8')).hexdigest()
    if isinstance(s, bytes):
        return hashlib.md5(s).hexdigest()
    else:
        print('get_MD5 ERROR:', s)
        return 'None'


def get_text_embeds(tags, model):
    tag_list = tags.strip().split(",")
    tokenize = model.get_tokenizer()
    text_feature = tokenize(tag_list, padding=True, truncation=True, return_tensors='pt', max_length=50)
    text = text_feature.to("cuda")
    with torch.no_grad():
        text_atts = text["attention_mask"]
        text_feats = model.encode_text(text)
        text_embeds = F.normalize(model.text_hidden_layer(text_feats[:,0,:]))

    text_embeds = text_embeds.detach().cpu().numpy()

    tag_num = text_embeds.shape[0]

    return tag_num, tag_list, text_atts, text_feats, text_embeds


def inference(image, model):
    # 相似度
    image = image.to("cuda")
    with torch.no_grad():
        image_feat = model.encode_image(image)
        image_embed = model.image_hidden_layer(image_feat[:,0,:])
        image_embed = F.normalize(image_embed, p=2, dim=1)

    image_embed = image_embed.cpu().detach().numpy()
    # 计算相似度获取标签
    image_embeds = np.repeat(image_embed, tag_num, axis=0)
    sim_i2t = np.dot(image_embeds, text_embeds.T)[0]

    # 相似度大于阈值的tag
    topk_idx = sim_i2t.argsort()[::-1][:20]
    topk_tags = tag_list[topk_idx]
    topk_scores = sim_i2t[topk_idx]

    # 消歧模型
    image_feats = image_feat.repeat(topk_idx.shape[0], 1, 1)
    with torch.no_grad():
        dect_scores = model.it_match(image_feats, text_feats[topk_idx.copy()], text_atts[topk_idx.copy()])
    dect_scores = dect_scores.cpu().detach().numpy()

    # 分类模型
    with torch.no_grad():
        logits = model.image_class(image_feat)
    logits = logits[0].sigmoid()
    logits = logits.cpu().detach().numpy()

    sort_index = logits.argsort()[::-1]
    sort_score = logits[sort_index]
    class_scores = sort_score[sort_score >= 0.5]
    class_indexs = sort_index[sort_score >= 0.5]
    class_tags = [poi_index2tag[val] for val in class_indexs]
    class_tag_dict = dict(zip(class_tags, class_scores))

    # 总分：保证一定相关性的基础上，判别模型高于一定阈值或者分类模型高于阈值
    res_dict = {}
    for tag, sim_score, dect_score in zip(topk_tags, topk_scores, dect_scores):
        class_score = class_tag_dict.get(tag, 0)
        final_score = (sim_score + max(dect_score, class_score))/2.0
        if sim_score >= sthred or final_score >= dthred:
            res_dict[tag] = final_score # sim_score, dect_score, class_score

    # res = sorted(res_dict.items(),key=lambda x:x[1], reverse=True)#[:3]

    return str(res_dict)


if __name__ == "__main__":
    mp.set_start_method("spawn", force=True)
    args = get_parser().parse_args()

    sthred = args.sthred
    dthred = args.dthred
    scale = args.scale
    config = {
        "model_path": "./weights/poi_tag_predict.pth",
        "bert_dic": "./weights/vocab.txt",
        "bert_config": "./weights/xbert_config.json",
        "embed_dim": 512,
        "image_feature_dim": 768,
        "num_class": 370,
        "index2tag": "./weights/poi_index2tag.npy",
        "image_size": 256
    }


    # 下载模型
    # os.makedirs('weights', exist_ok=True)
    image_size = config["image_size"]
    download_weights(args.model_path, config["model_path"])

    model = build_model(config)
    model = model.to("cuda")
    model.eval()

    # 文本向量
    poi_index2tag = np.load(config["index2tag"], allow_pickle=True).item()
    tag_num, tag_list, text_atts, text_feats, text_embeds = get_text_embeds(args.tags, model)
    tag_list = np.array(tag_list)

    print("Loading data...")
    with  common_io.table.TableReader(args.tables, slice_count=int(os.environ.get("WORLD_SIZE")), slice_id=int(os.environ.get("RANK"))) as reader:
        count_total = reader.get_row_count()
        if count_total <= 0:
            print('count_total==0')
            exit(0)
        print('>>>>> total count=', count_total)

    count = 1
    data_gen = data_generator(args.tables, batch_size=args.batch_size)

    begin = time.time()
    pool = ThreadPoolExecutor(max_workers=8)
    with common_io.table.TableWriter(args.outputs, slice_id=int(os.environ.get("RANK"))) as writer:
        try:
            while 1:
                input_data = next(data_gen)
                res = []
                input_data_after_thread = []
                # 预先多线程加载图片，否则会很慢
                all_task = [pool.submit(download_alicdn_url, x) for x in input_data]

                for future in as_completed(all_task):
                    data = future.result()
                    if data[-1] is not None:
                        input_data_after_thread.append(data)

                for item in input_data_after_thread:
                    url, img = item
                    try:
                        if url is None or len(url) < 1 or img is None:
                            continue
                        try:
                            tag_info = inference(img, model)
                        except Exception as e:
                            print(e, url)
                            traceback.print_exc()
                            continue

                        # score = infer_one_pic(cate, aes_score, model)
                        res.append((url, tag_info))

                    except Exception as e:
                        print(e)
                        traceback.print_exc()
                        continue

                if len(res) > 0:
                    indices = list(range(len(res[0])))
                    writer.write(res, indices)

                count += args.batch_size
                if count % (args.batch_size ** 2) == 1:
                    t = time.time()
                    print('\n', '*' * 15, get_time())
                    print('>>> Now', count, ' / ', count_total)
                    # print('MEM free:', bytes2human(psutil.virtual_memory().free))
                    # print('Disk Usage:', psutil.disk_usage(os.getcwd()))
                    print('AVG time is {:.2f} min for 1w pic'.format(
                        int(t - begin) * 10000 / 60 / count))
                    print('one pic is {:.2f}s'.format(int(t - begin) / count))
                    if count_total > 0:
                        print("process attr:{}".format(percentage(count / count_total)))
                if count >= args.limit > 0:
                    break

                gc.collect()
        except Exception as e:
            print('data_gen finish...', e)
            traceback.print_exc()

