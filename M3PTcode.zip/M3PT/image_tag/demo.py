# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved
import argparse
import glob
import hashlib
import multiprocessing as mp
import os
import time
import cv2, json
import sys
import numpy as np
import tqdm
import oss2
from io import BytesIO
import requests
import torch
from model.align_model_vit import build_model
from concurrent.futures import ThreadPoolExecutor, as_completed
from torchvision import transforms
from PIL import Image
from torchvision.transforms import InterpolationMode
import torch.nn.functional as F
import pandas as pd

def get_parser():
    parser = argparse.ArgumentParser(description="model for builtin models")
    parser.add_argument("--threshold", default=0.5, type=float, help="label threshold")
    parser.add_argument("--tags", default="拖伞,脱口秀", type=str, help="play tags")

    parser.add_argument("--url", default="", type=str, help="label index")

    return parser

def get_time():
    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))


def percentage(v):
    return "%.2f%%" % (v * 100)


headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'}
import base64 as b64
def download_alicdn_url(url):
    try:
        resp = requests.get(url=url, timeout=(3.05, 5), headers=headers)
    except:
        return None
    if resp.status_code != 200:
        print(url, "resp.code != 200", 'resp.status_code=', resp.status_code)
        data = None
    else:
        data = resp.content
        if data is None or len(data) == 0:
            retry_count = 3
            while retry_count > 0:
                retry_count -= 1
                try:
                    resp = requests.get(url=url, timeout=5)
                    data = resp.content
                    if data is not None and len(data) != 0:
                        break
                except Exception as e:
                    time.sleep(0.5)
                    print(">>> Temp Download fail: retry_count left:{}".format(retry_count), e)
            print(">>> Download fail: image {} failed to retry read.!".format(url))

    if data is None:
        return None

    # base64 = b64.b64encode(data)
    pil_img = Image.open(BytesIO(data)).convert('RGB')

    return pil_img


data_trans = transforms.Compose([
    transforms.Resize((256, 256), interpolation=InterpolationMode.BICUBIC),
    transforms.ToTensor(),
    transforms.Normalize((0.48145466, 0.4578275, 0.40821073), (0.26862954, 0.26130258, 0.27577711)),
    ])

import hashlib
def get_hash(url):
    sign = hashlib.md5(url.encode("utf8")).hexdigest()
    return sign

def get_MD5(s):
    if isinstance(s, str):
        return hashlib.md5(s.encode('utf-8')).hexdigest()
    if isinstance(s, bytes):
        return hashlib.md5(s).hexdigest()
    else:
        print('get_MD5 ERROR:', s)
        return 'None'

def build_oss_bucket():


    return bucket

def download_oss_url(bucket, path):
    object_stream = bucket.get_object(path).read()
    image = np.asarray(bytearray(object_stream), dtype="uint8")
    image = cv2.imdecode(image, cv2.IMREAD_COLOR)

    return image


def get_text_embeds(tags, model):
    tag_list = tags.strip().split(",")
    tokenize = model.get_tokenizer()
    text_feature = tokenize(tag_list, padding=True, truncation=True, return_tensors='pt', max_length=50)
    text = text_feature.to(device)
    with torch.no_grad():
        text_atts = text["attention_mask"]
        text_feats = model.encode_text(text)
        text_embeds = F.normalize(model.text_hidden_layer(text_feats[:,0,:]))

    text_embeds = text_embeds.detach().cpu().numpy()

    tag_num = text_embeds.shape[0]

    return tag_num, tag_list, text_atts, text_feats, text_embeds


def inference(image, model):
    # 相似度
    image = image.to("cuda")
    with torch.no_grad():
        image_feat = model.encode_image(image)
        image_embed = model.image_hidden_layer(image_feat[:,0,:])
        image_embed = F.normalize(image_embed, p=2, dim=1)

    image_embed = image_embed.cpu().detach().numpy()
    # 计算相似度获取标签
    image_embeds = np.repeat(image_embed, tag_num, axis=0)
    sim_i2t = np.dot(image_embeds, text_embeds.T)[0]

    # 相似度大于阈值的tag
    topk_idx = sim_i2t.argsort()[::-1][:20]
    topk_tags = tag_list[topk_idx]
    topk_scores = sim_i2t[topk_idx]

    # 消歧模型
    image_feats = image_feat.repeat(topk_idx.shape[0], 1, 1)
    with torch.no_grad():
        dect_scores = model.it_match(image_feats, text_feats[topk_idx.copy()], text_atts[topk_idx.copy()])
    dect_scores = dect_scores.cpu().detach().numpy()

    # 分类模型
    with torch.no_grad():
        logits = model.image_class(image_feat)
    logits = logits[0].sigmoid()
    logits = logits.cpu().detach().numpy()

    sort_index = logits.argsort()[::-1]
    sort_score = logits[sort_index]
    class_scores = sort_score[sort_score >= 0.5]
    class_indexs = sort_index[sort_score >= 0.5]
    class_tags = [poi_index2tag[val] for val in class_indexs]
    class_tag_dict = dict(zip(class_tags, class_scores))

    # 总分：保证一定相关性的基础上，判别模型高于一定阈值或者分类模型高于阈值
    res_dict = {}
    for tag, sim_score, dect_score in zip(topk_tags, topk_scores, dect_scores):
        class_score = class_tag_dict.get(tag, 0)
        final_score = (sim_score + max(dect_score, class_score))/2.0
        if sim_score >= sthred or final_score >= dthred:
            res_dict[tag] = final_score # sim_score, dect_score, class_score

    # res = sorted(res_dict.items(),key=lambda x:x[1], reverse=True)#[:3]

    return str(res_dict)


if __name__ == "__main__":
    mp.set_start_method("spawn", force=True)
    args = get_parser().parse_args()

    bucket = build_oss_bucket()
    threshold = args.threshold
    config = {
        "model_path": "./weights/poi_tag_predict.pth",
        "bert_dic": "./weights/bert/vocab.txt",
        "bert_config": "./weights/xbert_config.json",
        "embed_dim": 512,
        "image_feature_dim": 768,
        "image_size": 256,
        "num_class": 370
    }
    device = "cpu"
    model = build_model(config)
    model = model.to(device)
    model.eval()

    # 文本向量
    # poi_index2tag = np.load("poi_index2tag.npy", allow_pickle=True).item()
    tag_num, tag_list, text_atts, text_feats, text_embeds = get_text_embeds(args.tags, model)
    # import pdb; pdb.set_trace()
    # np.save('poi_index2tag', poi_index2tag)
    # np.save('play_tag_weight', text_embeds)
    # np.save('poi_tag_weight2', text_feats)
    tag_list = np.array(tag_list)

    while True:
        try:
            line = input("输入url: ")
            url = line.strip()
            img = download_alicdn_url(url)
            # import pdb; pdb.set_trace()
            img = data_trans(img)
            img = img.unsqueeze(0)
            pred_info = inference(img, model)
            print(pred_info)
        except Exception as e:
            print("error", e)
        if url == "q":
            break
